<?php
//Download Report Button PHP code Start From Here

if(isset($_POST["DownloadR"]))  
 {  
  $host="localhost";
  $user="root";
  $password="";
  $datab="logindb";
      $connect = mysqli_connect($host,$user,$password,$datab); 
      header('Content-Type: text/csv; charset=utf-8');  
      header('Content-Disposition: attachment; filename=data.csv');
      $output = fopen("php://output", "w");  
      fputcsv($output, array('Roll No.', 'Student Name', 'Moodle ID', 'Present', 'Absent', 'Total Lectures'));  
      $query = "SELECT * FROM sample_view_table";  
      $result = mysqli_query($connect, $query);  
      while($row = mysqli_fetch_assoc($result))  
      {  
           fputcsv($output, $row);  
      }  
      fclose($output);     
 }
 ?>