<!DOCTYPE html>
<html>
<head>
<title>Schedule Lecture</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="sidebar.css">


<style>
    .editbutton{
      color: white;
    }
      .editbutton:hover{
        background-color: #0082e6;
        color: white;
      }
  </style>
<style>
body {
  font-family: "Lato", sans-serif;
  background-image: url(AI.jpg);
  background-repeat: no-repeat;
  background-size: cover;
}

/* Fixed sidenav, full height */
.sidenav {
  height: 100%;
  width: 200px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  
}

/* Style the sidenav links and the dropdown button */
.sidenav a, .dropdown-btn {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
  border: none;
  background: none;
  width: 100%;
  text-align: left;
  cursor: pointer;
  outline: none;
}

/* On mouse-over */
.sidenav a:hover{
  color: #f1f1f1;
  background-color: #555;
}

/* Main content */
.main {
  margin-left: 200px; /* Same as the width of the sidenav */
  /*font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

/* Add an active class to the active dropdown button*/ 
.active {
  background-color: green;
  color: white;
}


/* Dropdown container (hidden by default). Optional: add a lighter background color and some left padding to change the design of the dropdown content 
.dropdown-container {
  display: none;
  background-color: #262626;
  padding-left: 8px;
}*/

/* Optional: Style the caret down icon */
.fa-caret-down {
  float: right;
  padding-right: 52px;
}

/* Add Student Dropdown*/
#adds{ padding-left: 6px; }
#adds:hover{
  color: white;
  background-color: none;
}

#addsDW{
  padding-right: 34px;
}

/*Notification Icon*/
.notification {
  background-color: #555;
  color: white;
  text-decoration: none;
  padding: 8px 8px;
  position: relative;
  display: inline-block;
  border-radius: 90px;
}

.notification:hover {
  background: red;
}

.badge {
  top: 42px;
  left: 144px;
  right:38px;
  width: 18px;
  height: 18px;
  /*padding: 2px 2px;*/
  display: flex;
  border-radius: 50%;
  background-color: red;
  color: white;
  position: absolute;
  align-items: center;
  justify-content: center;
  font-size: 15px;
}

@media screen and (max-width: 700px) {
  .sidenav {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidenav a {float: left;}
  div.content {margin-left: 0;}
  .sidenav .fa-caret-down {
  float: right;
  /*padding-left: 10px;*/
  padding-right: 310px;
  
}
.main {
  margin-left: 5px; /* Same as the width of the sidenav */
  /*font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

#addsDW{
  padding-right: 306px;
}

}/*media screen bracket close*/

/*Container style*/
* {
  box-sizing: border-box;
}

input[type=text], select, textarea {
  width: 40%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
  color: black;
  font-size: 18px;
}

input[type=submit] {
  background-color: #448ee4;
  color: white;
  width: 150px;
  height: 40px;
  font-size: 15px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  position: relative;
  text-align: center;
  
}

input[type=submit]:hover {
  background-color: #4CAF50;
}

.container {
  background-color: transparent;
  
}


/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

#SN{
  
  padding: 10px;
}

/*table css*/
table td,th{
  border-collapse: collapse;
  border: 2px solid black;
}
table {
  width: 100%;
  border-collapse: collapse;
  background-color: white;
  text-align: center;
}
table th{
  background-color: green;
}

/*Edit button CSS*/
.edit{
  color: white;
  width: 50px;
  height: 20px;
  font-size: 15px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  background-color: #448ee4;
  text-align: center;
}
.edit:hover{
  box-shadow: 2px 2px black;
}

/*save and cancel button CSS*/
.save{
  color: white;
  width: 90px;
  height: 40px;
  font-size: 15px;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  position: relative;
  background-color: #4CAF50;
}
.save:hover{
  background-color: red;
}
.cancel{
  color: white;
  width: 90px;
  height: 40px;
  font-size: 15px;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  padding: 10px;
  background-color: #4CAF50;
}
.cancel:hover{
  background-color: #448ee4;
}
</style>
</head>
<body>

<div class="sidenav">
  <a style="background-color: #448ee4; color: white" href="#"><b>E-Attendance</b></a>
  <a href="#">Notifications
  <i class="material-icons" style="font-size: 24px; top: 4px;align-items: center;position: relative;">notifications</i>
  <span class="badge">9</span>
  </a>

  <a href="Faculty_ScheduleLecture.php">Schedule Lectures</a>
  <a href="Faculty_Edit_Attendance.php">Edit Attendance</a>
  <a href="View_Attendance.php">View Attendence</a>
  <a href="Faculty_AddMessage.php">Add Message</a>
  <!-- Logout Button Code-->
  <a href="logout.php">Signout</a>
</div>

<center>
        <div class="container" style="padding-top: 20px;">
          <h2 style="color: green;">Schedule Lecture</h2>
          <br>
          <br>
          <form>
            <div class="row">
              <div class="col-25">
                <label for="sname"><b>Subject</b></label>
              </div>
              <div class="col-75">
                <select id="relation" name="relation">
                    <option value="Father">MAD</option>
                    <option value="Mother">END</option>
                    <option value="Gaurdian">AI</option>
                    <option value="Mother">CSL</option>
                    <option value="Gaurdian">IS</option>
                  </select>
              </div>
            </div>
            <div class="row">
              <div class="col-25">
                <label for="classroom"><b>Classroom</b></label>
              </div>
              <div class="col-75">
                <select id="relation" name="relation">
                    <option value="Father">201</option>
                    <option value="Mother">202</option>
                    <option value="Gaurdian">203</option>
                    <option value="Mother">204</option>
                    <option value="Gaurdian">205</option>
                  </select>
              </div>
            </div>
            <div class="row">
                <div class="col-25">
                  <label for="date"><b>Date</b></label>
                </div>
                <div class="col-75">
                  <input type="text" id="date" name="date" placeholder="MM/DD/YYYY">
                </div>
              </div>
            <div class="row">
              <div class="col-25">
                <label for="relation"><b>Timing</b></label>
              </div>
              <div class="col-25">
                <input type="text" id="time1" name="time1" placeholder="00:00">
              </div>
              <div class="col-25">
                <label for="relation"><b>To</b></label>
              </div> 
              <div class="col-25">
                <input type="text" id="time2" name="time2" placeholder="00:00">
              </div>
              
            </div>
        
            <div class="row">
                <div class="col-35">
                    <button class="button button4" input type="submit">Schedule</button>
                </div>
                <div class="col-40">                    
                    <button class="button button4" input type="submit" ><a href="Edit_Lecture.php" class="editbutton">Edit Schedule</a></button>
                </div>
            </div>

            <div class="row">
                <div class="col-75">
                    <input type="file" id="uploadfile" name="uploadfile">
                    <button class="button button4" input type="submit">Upload File</button>
                </div>
            </div>
            <div class="row">
              <center><input type="submit" value="Submit" style="padding-left: 150px; font-size: 16px;"></center>
            </div>
          </form>
        </div>
    
        </center>

<script>
/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}
</script>

</body>
</html> 
