<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Schedule Lecture</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="sidebar.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>

  <style>
    .editbutton{
      color: white;
    }
      .editbutton:hover{
        background-color: #0082e6;
        color: white;
      }
    body{
  background-image: url(laptop.jpg);
  background-repeat: no-repeat;
  background-size: cover;
}
label{
  font-weight: bold;
  font-size: 18px;
  color: orange;
}

.container{
background-color: transparent;
opacity: 0.9px;
}
  </style>

  </head>
  <body>
    <div id="Sidenav" class="sidebar">
        <a class="active" href="#">E-Attendence</a>
        <button class="dropdown-btn">Registration 
          <i class="fa fa-caret-down"></i>
        </button>
        <div class="dropdown-container">
          <button class="dropdown-btn">Add Students 
            <i class="fa fa-caret-down"></i>
          </button>
          <div class="dropdown-container">
            <a href="Add_Student.php">Register Student</a>
            <a href="#">Face Enrollment</a>
          </div>
          <a href="Add_Parents.php">Add Parents</a>
          <a href="#">Add Faculty</a>
        </div>

        <a href="Schedule_Lec_Admin.php">Schedule Lectures</a>
        <a href="Admin_ViewAttendance.php">View Attendance</a>
        <!--<a href="#">Camera/Classroom settings</a> -->
        <!-- Logout Button Code-->
        <a href="logout.php">Logout</a>

        
    </div>
    
    <center>
        <div class="container" style="padding-top: 20px;">
          <h2 style="color: White;">Schedule Lecture</h2>
          <br>
          <br>
          <form>
            <div class="row">
              <div class="col-25">
                <label for="sname">Subject</label>
              </div>
              <div class="col-75">
                <select id="relation" name="relation">
                    <option value="Father">MAD</option>
                    <option value="Mother">END</option>
                    <option value="Gaurdian">AI</option>
                    <option value="Mother">CSL</option>
                    <option value="Gaurdian">IS</option>
                  </select>
              </div>
            </div>
            <div class="row">
              <div class="col-25">
                <label for="classroom">Classroom</label>
              </div>
              <div class="col-75">
                <select id="relation" name="relation">
                    <option value="Father">201</option>
                    <option value="Mother">202</option>
                    <option value="Gaurdian">203</option>
                    <option value="Mother">204</option>
                    <option value="Gaurdian">205</option>
                  </select>
              </div>
            </div>
            <div class="row">
                <div class="col-25">
                  <label for="date">Date</label>
                </div>
                <div class="col-75">
                  <input type="text" id="date" name="date" placeholder="MM/DD/YYYY">
                </div>
              </div>
            <div class="row">
              <div class="col-25">
                <label for="relation">Timing</label>
              </div>
              <div class="col-25">
                <input type="text" id="time1" name="time1" placeholder="00:00">
              </div>
              <div class="col-25">
                <label for="relation">To</label>
              </div> 
              <div class="col-25">
                <input type="text" id="time2" name="time2" placeholder="00:00">
              </div>
              
            </div>
        
            <div class="row">
                <div class="col-35">
                    <button class="button button4" input type="submit">Schedule</button>
                </div>
                <div class="col-40">                    
                    <button class="button button4" input type="submit" ><a href="Admin_Edit_Schedule.php" class="editbutton">Edit Schedule</a></button>
                </div>
            </div>

            <div class="row">
                <div class="col-75">
                    <input type="file" id="uploadfile" name="uploadfile">
                    <button class="button button4" input type="submit">Upload File</button>
                </div>
            </div>
            <div class="row">
              <input type="submit" value="Submit">
            </div>
          </form>
        </div>
    
        </center>
    
    <script>
      function openNav() {
        document.getElementById("Sidenav").style.width = "250px";
        document.getElementById("main").style.marginLeft = "250px";
        document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
      }
      
      function closeNav() {
        document.getElementById("Sidenav").style.width = "0";
        document.getElementById("main").style.marginLeft= "0";
        document.body.style.backgroundColor = "white";
      }
      </script>
      <script>
        var dropdown = document.getElementsByClassName("dropdown-btn");
        var i;

        for (i = 0; i < dropdown.length; i++) {
        dropdown[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var dropdownContent = this.nextElementSibling;
        if (dropdownContent.style.display === "block") {
        dropdownContent.style.display = "none";
        } else {
        dropdownContent.style.display = "block";
        }
        });
      }
      </script>   
  </body>
</html>
