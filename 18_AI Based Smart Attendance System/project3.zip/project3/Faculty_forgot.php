<?php
session_start();
$host="localhost";
$user="root";
$password="";
$datab="logindb";

$conn=mysqli_connect($host,$user,$password,$datab);
#mysqli_select_db($datab);

if(isset($_POST['sendotp'])){
    
    $fEmail=$_POST['email'];
    $fmobilenum=$_POST['mnum'];
    
    $sql="select * from faculty_details where f_email='".$fEmail."'AND f_mobilenum='".$fmobilenum."' limit 1";
    
    $result=mysqli_query($conn,$sql);

if(empty($_POST['email']) && empty($_POST['mnum'])){
    echo"<script>alert('Please Enter Email and Mobile Number!!!');window.location='Faculty_forgot.php'</script>";

}

else{
    if(mysqli_num_rows($result)==1){
        
        $otp=mt_rand(1000, 9999);
        $message = 'Your OTP is '. $otp . '. Enter otp and click on verify button.';
        $_SESSION['email']= $fEmail;

    $fields = array(
    "sender_id" => "TXTIND",
    "message" => $message,
    "route" => "v3",
    "numbers" => $fmobilenum,
    );

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_SSL_VERIFYHOST => 0,
  CURLOPT_SSL_VERIFYPEER => 0,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => json_encode($fields),
  CURLOPT_HTTPHEADER => array(
    "authorization: fuZPHMv0RCL83yriVoY1dAI4eFX6bUhQazOSkxwqK7Es9jmWTJALbmt5cq7GpjhrzoWUnETDHOy42Xi3",
    "accept: */*",
    "cache-control: no-cache",
    "content-type: application/json"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  setcookie('otp',$otp);
}
    } //IF close bracket
    else{
       echo"<script>alert('You Have Entered Incorrect Mobile Number!!!');window.location='Faculty_forgot.php'</script>";
        #header("Location:example.php");
    }
    
    }
}
if(isset($_POST['submit'])){
    $otp= $_POST['otp'];
    if ($_COOKIE['otp']==$otp) {
        echo "<script>window.location='Faculty_newpass.php'</script>";
    }
    else{
        echo "<script>alert('You Have Enter Wrong OTP!!!'); window.location='Faculty_forgot.php'</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Faculty Forgot Password</title>
</head>
<body class="bstyle">
    <div class="loginbox">
    <img src="login-icon.png" class="avtar">
        <h1 class="text1">Forgot Password</h1>
        <form action="Faculty_forgot.php" method="POST">
            <p>Email</p>
            <input type="text" name="email" placeholder="Enter Email">
            <p>Mobile Number</p>
            <input type="text" name="mnum" placeholder="Enter Mobile Number">
            <input type="submit" name="sendotp" value="Send OTP">
            <input type="text" name="otp" placeholder="Enter OTP">
            <input type="submit" name="submit" value="Verify">
            <center><a href="Faculty_login.php" style="text-align: center; font-size: 20px;">Login</a></center>
        </form>
        
    </div>>

</body>
</html>
<!--https://www.soengsouy.com/2020/09/forgot-password-recovery-using-php-and.html
#https://www.youtube.com/watch?v=GiHaXbBTsL4&t=215s -->