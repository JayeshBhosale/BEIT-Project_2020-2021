<?php
session_start();
$host="localhost";
$user="root";
$password="";
$datab="logindb";

$conn=mysqli_connect($host,$user,$password,$datab);
#mysqli_select_db($datab);

if(isset($_POST['sendotp'])){
    
    $Email=$_POST['email'];
    $mobilenum=$_POST['mnum'];
    
    $sql="select * from parents_detail where p_email='".$Email."'AND mobile_num='".$mobilenum."' limit 1";
    
    $result=mysqli_query($conn,$sql);

if(empty($_POST['email']) && empty($_POST['mnum'])){
    echo"<script>alert('Please Enter Email and Mobile Number!!!');window.location='forgotPass.php'</script>";

}

else{
    if(mysqli_num_rows($result)==1){
        
        $otp=mt_rand(1000, 9999);
        $message = 'Your OTP is '. $otp . '. Enter otp and click on verify button.';
        $_SESSION['email']= $Email;

        $fields = array(
    "sender_id" => "TXTIND",
    "message" => $message,
    "route" => "v3",
    "numbers" => $mobilenum,
    );

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_SSL_VERIFYHOST => 0,
  CURLOPT_SSL_VERIFYPEER => 0,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => json_encode($fields),
  CURLOPT_HTTPHEADER => array(
    "authorization: fuZPHMv0RCL83yriVoY1dAI4eFX6bUhQazOSkxwqK7Es9jmWTJALbmt5cq7GpjhrzoWUnETDHOy42Xi3",
    "accept: */*",
    "cache-control: no-cache",
    "content-type: application/json"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  setcookie('otp',$otp);
}
    }
    else{
       echo"<script>alert('You Have Entered Incorrect Mobile Number!!!');window.location='forgotPass.php'</script>";
        #header("Location:example.php");
    }
    
    }
}
if(isset($_POST['submit'])){
    $otp= $_POST['otp'];
    if ($_COOKIE['otp']==$otp) {
        echo "<script>window.location='new_pass.php'</script>";
    }
    else{
        echo "<script>alert('You Have Enter Wrong OTP!!!'); window.location='forgotPass.php'</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Parent's Forgot Password</title>
</head>
<body class="bstyle">
    <div class="loginbox">
    <img src="login-icon.png" class="avtar">
        <h1 class="text1">Forgot Password</h1>
        <form action="forgotPass.php" method="POST">
            <p>Email</p>
            <input type="text" name="email" placeholder="Enter Email">
            <p>Mobile Number</p>
            <input type="text" name="mnum" placeholder="Enter Mobile Number">
            <input type="submit" name="sendotp" value="Send OTP">
            <input type="text" name="otp" placeholder="Enter OTP">
            <input type="submit" name="submit" value="Verify">
            <center><a href="Parents_login.php" style="text-align: center; font-size: 20px;">Login</a></center>
        </form>
        
    </div>>

</body>
</html>
<!--https://www.soengsouy.com/2020/09/forgot-password-recovery-using-php-and.html
#https://www.youtube.com/watch?v=GiHaXbBTsL4&t=215s -->