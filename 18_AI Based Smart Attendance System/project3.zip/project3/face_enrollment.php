<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Face Enrollment</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="sidebar.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  </head>
  <body>
    <div id="Sidenav" class="sidebar">
        <a class="active" href="#">E-Attendence</a>
        <button class="dropdown-btn">Registration 
          <i class="fa fa-caret-down"></i>
        </button>
        <div class="dropdown-container">
          <button class="dropdown-btn">Add Students 
            <i class="fa fa-caret-down"></i>
          </button>
          <div class="dropdown-container">
            <a href="Add_Student.php">Register Student</a>
            <a href="face_enrollment.php">Face Enrollment</a>
          </div>
          <a href="Add_Parents.php">Add Parents</a>
          <a href="add_faculty.php">Add Faculty</a>
        </div>

        <a href="Schedule_Lec_Admin.php">Schedule Lectures</a>
        <a href="#">View Attendence</a>
      <!-- <a href="#">Camera/Classroom settings</a> -->

        <!-- Logout Button Code-->
      <a href="logout.php">Logout</a>

    </div>

    <center>
      <h2 style="color: white blue; padding-top: 20px;">Face Enrollment</h2>
    <br>
    <br>
    <div class="container" style="padding-top: 20px;">
      <form>
        <div class="row">
          <div class="col-25">
            <label for="mooodle_id" style="font-size: 18px;">Moodle Id</label>
          </div>
          <div class="col-25">
            <select id="mooodle_id" name="mooodle_id" style="size: 50px;">
              <option value="18204009">18204009</option>
              <option value="17104031">17104031</option>
              <option value="17104014">17104014</option>
            </select>
          </div>
        </div><br>
        <div class="row">
            <div class="col">
                <div class="w3-card-4" style="size: 50px;">
                    <img src="Detect_Face.jpeg" alt="Person">
                </div>
            </div>
        </div><br><br>
        <div class="row">
          <input type="submit" value="Enroll Student">
        </div>
      </form>
    </div>

    </center>


    <script>
      function openNav() {
        document.getElementById("Sidenav").style.width = "250px";
        document.getElementById("main").style.marginLeft = "250px";
        document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
      }
      
      function closeNav() {
        document.getElementById("Sidenav").style.width = "0";
        document.getElementById("main").style.marginLeft= "0";
        document.body.style.backgroundColor = "white";
      }
      </script>
      <script>
        var dropdown = document.getElementsByClassName("dropdown-btn");
        var i;

        for (i = 0; i < dropdown.length; i++) {
        dropdown[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var dropdownContent = this.nextElementSibling;
        if (dropdownContent.style.display === "block") {
        dropdownContent.style.display = "none";
        } else {
        dropdownContent.style.display = "block";
        }
        });
      }
      </script>   
  </body>
</html>
