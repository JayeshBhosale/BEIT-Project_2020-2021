<!DOCTYPE html>
<html>
<head>
<title>Faculty Add Message</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<style>
body {
  font-family: "Lato", sans-serif;
  background-image: url(laptop.jpg);
  background-repeat: no-repeat;
  background-size: cover;
}

/* Fixed sidenav, full height */
.sidenav {
  height: 100%;
  width: 200px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  
}

/* Style the sidenav links and the dropdown button */
.sidenav a, .dropdown-btn {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
  border: none;
  background: none;
  width: 100%;
  text-align: left;
  cursor: pointer;
  outline: none;
}

/* On mouse-over */
.sidenav a:hover{
  color: #f1f1f1;
  background-color: #555;
}

/* Main content */
.main {
  margin-left: 200px; /* Same as the width of the sidenav */
  /*font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

/* Add an active class to the active dropdown button*/ 
.active {
  background-color: green;
  color: white;
}


/* Dropdown container (hidden by default). Optional: add a lighter background color and some left padding to change the design of the dropdown content */
.dropdown-container {
  display: none;
  background-color: #262626;
  padding-left: 8px;
}

/* Optional: Style the caret down icon */
.fa-caret-down {
  float: right;
  padding-right: 52px;
}

/* Add Student Dropdown*/
#adds{ padding-left: 6px; }
#adds:hover{
  color: white;
  background-color: none;
}

#addsDW{
  padding-right: 34px;
}

/*Notification Icon*/
.notification {
  background-color: #555;
  color: white;
  text-decoration: none;
  padding: 8px 8px;
  position: relative;
  display: inline-block;
  border-radius: 90px;
}

.notification:hover {
  background: red;
}

.badge {
  top: 42px;
  left: 144px;
  right:38px;
  width: 18px;
  height: 18px;
  /*padding: 2px 2px;*/
  display: flex;
  border-radius: 50%;
  background-color: red;
  color: white;
  position: absolute;
  align-items: center;
  justify-content: center;
  font-size: 15px;
}

@media screen and (max-width: 700px) {
  .sidenav {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidenav a {float: left;}
  div.content {margin-left: 0;}
  .sidenav .fa-caret-down {
  float: right;
  /*padding-left: 10px;*/
  padding-right: 310px;
  
}
.main {
  margin-left: 5px; /* Same as the width of the sidenav */
  /*font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

#addsDW{
  padding-right: 306px;
}

}/*media screen bracket close*/

/*Container style*/
* {
  box-sizing: border-box;
}

input[type=text], select, textarea {
  width: 40%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
  color: white;
  font-size: 18px;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  width: 100px;
  height: 40px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  position: relative;
  
}

input[type=submit]:hover {
  background-color: #448ee4;
}

.container {
  border-radius: 5px;
  background-color: light white;
  padding: 20px;
  opacity: 0.9;
}

.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
  padding-left: 25px;
  
}

.col-75 {
  float: right;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

#SN{
  
  padding-left: 3px;
}
</style>
</head>
<body>

<div class="sidenav">
  <a style="background-color: #448ee4; color: white" href="#"><b>E-Attendance</b></a>
  <a href="#">Notifications
  <i class="material-icons" style="font-size: 24px; top: 4px;align-items: center;position: relative;">notifications</i>
  <span class="badge">9</span>
  </a>

  <a href="Faculty_ScheduleLecture.php">Schedule Lectures</a>
  <a href="Faculty_Edit_Attendance.php">Edit Attendance</a>
  <a href="View_Attendance.php">View Attendence</a>
  <a href="Faculty_AddMessage.php">Add Message</a>
  <!-- Logout Button Code-->
  <a href="logout.php">Signout</a>
</div>

<div class="main">
  <div class="container">
    <h2 style="color: Green;text-align: center;">Add Message</h2><br>
  <form action="/action_page.php">
    <div class="row">
      <div class="col-25">
        <label for="fsname" id="SN">Select Name</label>
      </div>
      <div class="col-75">
        <select id="country" name="fsname">
          <option value="none">--Select--</option>
          <option value="name1">Jayesh Bhosale</option>
          <option value="name2">Yash Gangani</option>
          <option value="name3">Tejas Bhanushali</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="msg"id="SN">Message</label>
      </div>
      <div class="col-75">
        <textarea id="subject" name="msg" placeholder="Write something.." style="height:200px"></textarea>
      </div>
    </div><br>
    <div class="row">
      <center><input type="submit" value="Send"></center>
    </div>
  </form>
  </div>
</div>

<script>
/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}
</script>

</body>
</html> 
