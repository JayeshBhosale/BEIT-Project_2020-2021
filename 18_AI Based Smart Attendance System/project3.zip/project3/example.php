<!DOCTYPE html>
<html>
<head>
	<title>Admin Login</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://www.google.com/recaptcha/api.js" async defer></script>
<?php
session_start();

$host="localhost";
$user="root";
$password="";
$datab="logindb";

$conn=mysqli_connect($host,$user,$password,$datab);
#mysqli_select_db($datab);

if(isset($_POST['username'])){
    
    $uname=$_POST['username'];
    $password=$_POST['password'];
    
    $sql="select * from login where username='".$uname."'AND passwd='".$password."' limit 1";
    
    $result=mysqli_query($conn,$sql);

    if(empty($uname)){
    	    	echo"<script>alert('Please Entered Username!!!');window.location='example.php'</script>";
    }
    else{
    if(mysqli_num_rows($result)==1){
        //echo "<script>alert('You Have Successfully Logged in!!!'); window.location='After_login_Admin.php'</script>";
       	#header("Location:aboutus.php");
       	$_SESSION['username']= $uname;

        //recaptcha code
        if (isset($_POST['g-recaptcha-response'])) 
        {
            $secretkey= "Put site Key here";
            $ip= $_SERVER['REMOTE_ADDR'];
            $response= $_POST['g-recaptcha-response'];
            $url= "https://www.google.com/recaptcha/api/siteverify?secret=$secretkey&response=$response&remoteip=$ip";
            $fire= file_get_contents($url);
            $data= json_decode($fire);
            //Data check
            if($data->success==true)
            {
              echo "<script>alert('You Have Successfully Logged in!!!'); window.location='Add_Parents.php'</script>";
            }
            else
            {
              echo"<script>alert('Recaptcha Error!!!');window.location='example.php'</script>";
            }
        }
        else
        {
            echo"<script>alert('Please check recaptcha!!!');window.location='example.php'</script>";
        }
    }
    else{
       echo"<script>alert('You Have Entered Incorrect Password!!!');window.location='example.php'</script>";
        #header("Location:example.php");
    }
     }
}
	?>

</head>
<body class="bstyle">
	<div class="navbar">
  		<a class="active" href="#"><i class="fa fa-fw fa-home"></i> Home</a> 
  		<!--<a href="#"><i class="fa fa-fw fa-search"></i> Search</a>--> 
  		<a href="aboutus.php"><i class="fa fa-fw fa-user"></i> About us</a>
  		<a href="contactus.php"><i class="fa fa-fw fa-envelope"></i> Contact us</a> 
	</div>

	<div class="loginbox"style="height: 430px; width: 360px;">
	<img src="login-icon.png" class="avtar"style="width: 100px;height: 100px;border-radius: 50%;position: center;top:-50px;left: 136px;">
		<h1 class="text1">Admin Login</h1>
		<form action="example.php" method="POST">
			<p>Username</p>
			<input type="text" name="username" placeholder="Enter Username">
			<p>Password</p>
			<input type="Password" name="password" placeholder="Enter Password">
      <div class="g-recaptcha" data-sitekey="put site key here"></div><br>
			<input type="submit" name="log" value="Login" href="Add_Parents.php">
			<a href="admin_forgotpass.php" class="fp">Forgot Password</a><a href="admin_forgotpass.php" class="qm">?</a>
		</form>
		
	</div>>

</body>
</html>