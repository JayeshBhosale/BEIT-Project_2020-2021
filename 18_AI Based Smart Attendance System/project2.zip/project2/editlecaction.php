<?php 
$host="localhost";
$user="root";
$password="";
$datab="logindb";

$conn=mysqli_connect($host,$user,$password,$datab);

$input = filter_input_array(INPUT_POST);

/*$rno= $row['rno'];
$sname= $row['sname'];
$moodle_id= $row['moodle_id'];
$Date= $row['Date'];
$timing= $row['timing'];
$status= $row['status'];*/

$sub = mysqli_real_escape_string($conn, $input["subject"]);
$date = mysqli_real_escape_string($conn, $input["date"]);
$timing = mysqli_real_escape_string($conn, $input["timing"]);

if($input["action"] === 'edit')
{
 $query = "
 update lecture 
 set subject = '".$sub."', 
 date = '".$date."', 
 timing = '".$timing."',  
 WHERE id = '".$input["id"]."'
 ";

 mysqli_query($conn, $query);

}
if($input["action"] === 'delete')
{
 $query = "
 delete from lecture 
 WHERE id = '".$input["id"]."'
 ";
 mysqli_query($connect, $query);
}

echo json_encode($input);

?>