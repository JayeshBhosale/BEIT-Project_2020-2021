<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<style>

.dropdown {
  float: right;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 15px;  
  border: none;
  outline: none;
  color: red;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.dropdown:hover .dropbtn {
  background-color: #4CAF50;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: black;
  color: white;
}

.dropdown:hover .dropdown-content {
  display: block;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}
</style>
</head>
<body background="none">

<div class="navbar">
      <a class="active" href="example.php"><i class="fa fa-fw fa-home"></i> Home</a> 
      <!--<a href="#" ><i class="fa fa-fw fa-search"></i> Search</a>--> 
      <a href="aboutus.php" class="ab"><i class="fa fa-fw fa-user"></i> About us</a>
      <a href="contactus.php" class="con"><i class="fa fa-fw fa-envelope"></i> Contact us</a>
<div class="dropdown">
    <button class="dropbtn"> <?php echo($_SESSION['username']);?>
      <i class="material-icons" style="font-size: 14px;">power_settings_new</i>
    </button>
    <div class="dropdown-content">
      <a href="logout.php">Logout </a>
    </div>
  </div> 
</div>

</body>
</html>