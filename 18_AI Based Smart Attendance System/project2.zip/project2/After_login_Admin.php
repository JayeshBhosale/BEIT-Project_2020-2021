<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="sidebar.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  </head>
  <body>
    <div id="Sidenav" class="sidebar">
        <a class="active" href="#">E-Attendence</a>
        <button class="dropdown-btn">Registration 
          <i class="fa fa-caret-down"></i>
        </button>
        <div class="dropdown-container">
          <button class="dropdown-btn">Add Students 
            <i class="fa fa-caret-down"></i>
          </button>
          <div class="dropdown-container">
            <a href="Add_Student.php">Register Student</a>
            <a href="#">Face Enrollment</a>
          </div>
          <a href="Add_Parents.php">Add Parents</a>
          <a href="#">Add Faculty</a>
        </div>

        <a href="Schedule_Lec_Admin.php">Schedule Lectures</a>
        <a href="Admin_ViewAttendance.php">View Attendence</a>
        <!--<a href="#">Camera/Classroom settings</a> -->
        <a href="logout.php">Logout</a>
    </div>
    <div>
      <center><h1 style="color: red; padding-top: 25px;">Admin Dashboard</h1></center>
    </div>
    <script>
      function openNav() {
        document.getElementById("Sidenav").style.width = "250px";
        document.getElementById("main").style.marginLeft = "250px";
        document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
      }
      
      function closeNav() {
        document.getElementById("Sidenav").style.width = "0";
        document.getElementById("main").style.marginLeft= "0";
        document.body.style.backgroundColor = "white";
      }
      </script>
      <script>
        var dropdown = document.getElementsByClassName("dropdown-btn");
        var i;

        for (i = 0; i < dropdown.length; i++) {
        dropdown[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var dropdownContent = this.nextElementSibling;
        if (dropdownContent.style.display === "block") {
        dropdownContent.style.display = "none";
        } else {
        dropdownContent.style.display = "block";
        }
        });
      }
      </script>   
  </body>
</html>
