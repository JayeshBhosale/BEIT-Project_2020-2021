<!DOCTYPE html>
<html>
<head>
<title>Check Attendance</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<style>
body {
  font-family: "Lato", sans-serif;
}

/* Fixed sidenav, full height */
.sidenav {
  height: 100%;
  width: 200px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  
}

/* Style the sidenav links and the dropdown button */
.sidenav a, .dropdown-btn {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
  border: none;
  background: none;
  width: 100%;
  text-align: left;
  cursor: pointer;
  outline: none;
}

/* On mouse-over */
.sidenav a:hover{
  color: #f1f1f1;
  background-color: #555;
}

/* Main content */
.main {
  margin-left: 200px; /* Same as the width of the sidenav */
  /*font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

/* Add an active class to the active dropdown button*/ 
.active {
  background-color: green;
  color: white;
}


/* Dropdown container (hidden by default). Optional: add a lighter background color and some left padding to change the design of the dropdown content */
.dropdown-container {
  display: none;
  background-color: #262626;
  padding-left: 8px;
}

/* Optional: Style the caret down icon */
.fa-caret-down {
  float: right;
  padding-right: 52px;
}

/* Add Student Dropdown*/
#adds{ padding-left: 6px; }
#adds:hover{
  color: white;
  background-color: none;
}

#addsDW{
  padding-right: 34px;
}

/*Notification Icon*/
.notification {
  background-color: #555;
  color: white;
  text-decoration: none;
  padding: 8px 8px;
  position: relative;
  display: inline-block;
  border-radius: 90px;
}

.notification:hover {
  background: red;
}

.badge {
  top: 42px;
  left: 144px;
  right:38px;
  width: 18px;
  height: 18px;
  /*padding: 2px 2px;*/
  display: flex;
  border-radius: 50%;
  background-color: red;
  color: white;
  position: absolute;
  align-items: center;
  justify-content: center;
  font-size: 15px;
}

@media screen and (max-width: 700px) {
  .sidenav {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidenav a {float: left;}
  div.content {margin-left: 0;}
  .sidenav .fa-caret-down {
  float: right;
  /*padding-left: 10px;*/
  padding-right: 310px;
  
}
.main {
  margin-left: 5px; /* Same as the width of the sidenav */
  /*font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

#addsDW{
  padding-right: 306px;
}

}/*media screen bracket close*/

/*Container style*/
* {
  box-sizing: border-box;
}

input[type=text], select, textarea {
  width: 40%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

input[type=submit] {
  background-color: #448ee4;
  color: white;
  width: 150px;
  height: 40px;
  font-size: 15px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  position: relative;
  
}

input[type=submit]:hover {
  background-color: #4CAF50;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}


/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

#SN{
  
  padding: 10px;
}

/*table css*/
table td,th{
  border-collapse: collapse;
  border: 2px solid black;
}
table {
  width: 100%;
  border-collapse: collapse;
  background-color: white;
  text-align: center;
}
table th{
  background-color: green;
}

/*Download Report button CSS*/
.DR{
  color: white;
  width: 150px;
  height: 40px;
  font-size: 15px;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  position: relative;
  background-color: #448ee4;
}
.DR:hover{
  background-color: #4CAF50;
}
</style>
</head>
<body>

<div class="sidenav">
  <a style="background-color: #448ee4; color: white" href="#"><b>E-Attendance</b></a>
  <a href="#">Notifications
  <i class="material-icons" style="font-size: 24px; top: 4px;align-items: center;position: relative;">notifications</i>
  <span class="badge">9</span>
  </a>


  <a href="check_attendance.php">Check Attendance</a>

  <a href="Faculty_AddMessage.php">Add Message</a>
  <!-- Logout Button Code-->
  <a href="logout.php">Signout</a>
</div>

<div class="main">
  <div class="container">
    <h2 style="color: Green;text-align: center;">Check Attendance</h2><br>
    <br>
    <h2>Search Attendance by Adedamic Year</h2>
    <br>
    <br>


  <form action="/action_page.php">
    <div class="row">
      <div class="column">
        <label for="subject" id="SN">Subject</label>
      
        <select id="subject" name="subject" style="width:20%">
          <option value="none">Select Academic Year</option>
          <option value="">17-18</option>
          <option value="">18-19</option>
          <option value="3">19-20</option>
          <option value="">20-21</option>
        </select>
      </div>
    </div>
    <div class="row">
      <input type="submit" value="Generate Report">
    </div>

    <div class="col-75">
    <div class='tableauPlaceholder' id='viz1617823442457' style='position: relative'><noscript><a href='#'><img alt='Attendance Visualization ' src='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Bo&#47;Book1_16178234107550&#47;AttendanceVisualization&#47;1_rss.png' style='border: none' /></a></noscript><object class='tableauViz'  style='display:none;'><param name='host_url' value='https%3A%2F%2Fpublic.tableau.com%2F' /> <param name='embed_code_version' value='3' /> <param name='site_root' value='' /><param name='name' value='Book1_16178234107550&#47;AttendanceVisualization' /><param name='tabs' value='no' /><param name='toolbar' value='yes' /><param name='static_image' value='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Bo&#47;Book1_16178234107550&#47;AttendanceVisualization&#47;1.png' /> <param name='animate_transition' value='yes' /><param name='display_static_image' value='yes' /><param name='display_spinner' value='yes' /><param name='display_overlay' value='yes' /><param name='display_count' value='yes' /><param name='language' value='en' /><param name='filter' value='publish=yes' /></object></div>                <script type='text/javascript'>                    var divElement = document.getElementById('viz1617823442457');                    var vizElement = divElement.getElementsByTagName('object')[0];                    if ( divElement.offsetWidth > 800 ) { vizElement.style.width='1000px';vizElement.style.height='827px';} else if ( divElement.offsetWidth > 500 ) { vizElement.style.width='1000px';vizElement.style.height='827px';} else { vizElement.style.width='100%';vizElement.style.height='777px';}                     var scriptElement = document.createElement('script');                    scriptElement.src = 'https://public.tableau.com/javascripts/api/viz_v1.js';                    vizElement.parentNode.insertBefore(scriptElement, vizElement);                </script>
    </div>



    <br>
    <br>
    <br>
    <br><h2>Search Attendance by Date</h2>


    <div class="row">
      <div class="column">
        <label for="msg"id="SN" style="padding: 20px;">Date</label>
        <input type="date" name="fdate">
      </div>
    </div><br>
    <div class="row">
      <input type="submit" value="Generate Report">
    </div>
  </form><br><br>
  <div class="Table">
  <table class="table table-bordered">
    <tr>
      <th>Sr no.</th>
      <th>Subject</th>
      <th>Time</th>
      <th>Present</th>
      <th>Absent</th>
    </tr>
    <tr>
      <td>1.</td>
      <td>DSA</td>
      <td>1:00</td>
      <td>Yes</td>
      <td>No</td>
    </tr>
    <tr>
      <td>2.</td>
      <td>DBMS</td>
      <td>1:45</td>
      <td>No</td>
      <td>Yes</td>
    </tr>
    <tr>
    <td>3.</td>
      <td>POC</td>
      <td>2:30</td>
      <td>Yes</td>
      <td>No</td>
    </tr>
    <tr>
    <td>4.</td>
      <td>AM-III</td>
      <td>11:00</td>
      <td>Yes</td>
      <td>No</td>
    </tr>
    <tr>
    <td>5.</td>
      <td>DSA Lab</td>
      <td>10:00</td>
      <td>No</td>
      <td>Yes</td>
    </tr>
    <tr>
    <td>6.</td>
      <td>SQL Lab</td>
      <td>9:00</td>
      <td>Yes</td>
      <td>No</td>
    </tr>
    <tr>
    <td>7.</td>
      <td>POC Lab</td>
      <td>4:15</td>
      <td>Yes</td>
      <td>No</td>
    </tr>
  </table>
  </div><br>
  <center><button class="DR">Download Report</button></center>
  </div>
</div>

<script>
/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}
</script>

</body>
</html> 
