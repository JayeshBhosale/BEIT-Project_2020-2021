<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="sidebar.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>


<style>
body {
  font-family: "Lato", sans-serif;
  background-image: url(AI.jpg);
  background-repeat: no-repeat;
  background-size: cover;
}
label{
  font-weight: bold;
  font-size: 18px;
  color: blue;
}


/* Fixed sidenav, full height */
.sidenav {
  height: 100%;
  width: 200px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  
}

/* Style the sidenav links and the dropdown button */
.sidenav a, .dropdown-btn {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
  border: none;
  background: none;
  width: 100%;
  text-align: left;
  cursor: pointer;
  outline: none;
}

/* On mouse-over */
.sidenav a:hover{
  color: #f1f1f1;
  background-color: #555;
}

/* Main content */
.main {
  margin-left: 200px; /* Same as the width of the sidenav */
  /*font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

/* Add an active class to the active dropdown button*/ 
.active {
  background-color: green;
  color: white;
}


/* Dropdown container (hidden by default). Optional: add a lighter background color and some left padding to change the design of the dropdown content 
.dropdown-container {
  display: none;
  background-color: #262626;
  padding-left: 8px;
}*/

/* Optional: Style the caret down icon 
.fa-caret-down {
  float: right;
  padding-right: 52px;
}*/

/* Add Student Dropdown*/
#adds{ padding-left: 6px; }
#adds:hover{
  color: white;
  background-color: none;
}

#addsDW{
  padding-right: 34px;
}

/*Notification Icon*/
.notification {
  background-color: #555;
  color: white;
  text-decoration: none;
  padding: 8px 8px;
  position: relative;
  display: inline-block;
  border-radius: 90px;
}

.notification:hover {
  background: red;
}

.badge {
  top: 42px;
  left: 144px;
  right:38px;
  width: 18px;
  height: 18px;
  /*padding: 2px 2px;*/
  display: flex;
  border-radius: 50%;
  background-color: red;
  color: white;
  position: absolute;
  align-items: center;
  justify-content: center;
  font-size: 15px;
}

@media screen and (max-width: 700px) {
  .sidenav {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidenav a {float: left;}
  div.content {margin-left: 0;}
  .sidenav .fa-caret-down {
  float: right;
  /*padding-left: 10px;*/
  padding-right: 310px;
  
}
.main {
  margin-left: 5px; /* Same as the width of the sidenav */
  /*font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

#addsDW{
  padding-right: 306px;
}

}/*media screen bracket close*/

/*Container style*/
* {
  box-sizing: border-box;
}

input[type=text], select, textarea {
  width: 40%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

input[type=submit] {
  background-color: #448ee4;
  color: white;
  width: 150px;
  height: 40px;
  font-size: 15px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  position: relative;
  text-align: center;
  
}

input[type=submit]:hover {
  background-color: #4CAF50;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
  background-color: transparent;
opacity: 0.9px;
}


/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

#SN{
  
  padding: 10px;
}

/*table css*/
table td,th{
  border-collapse: collapse;
  border: 2px solid black;
}
table {
  width: 100%;
  border-collapse: collapse;
  background-color: white;
  text-align: center;
}
table th{
  background-color: green;
}

/*Download Report button CSS*/
.DR{
  color: white;
  width: 150px;
  height: 40px;
  font-size: 15px;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  position: relative;
  background-color: #448ee4;
}
.DR:hover{
  background-color: #4CAF50;
}
</style>    
  </head>
  <body>
    <div id="Sidenav" class="sidebar">
        <a class="active" href="#">E-Attendence</a>
        <button class="dropdown-btn">Registration 
          <i class="fa fa-caret-down"></i>
        </button>
        <div class="dropdown-container">
          <button class="dropdown-btn">Add Students 
            <i class="fa fa-caret-down"></i>
          </button>
          <div class="dropdown-container">
            <a href="Add_Student.php">Register Student</a>
            <a href="#">Face Enrollment</a>
          </div>
          <a href="Add_Parents.php">Add Parents</a>
          <a href="#">Add Faculty</a>
        </div>

        <a href="Schedule_Lec_Admin.php">Schedule Lectures</a>
        <a href="Admin_ViewAttendance.php">View Attendence</a>
        <!--<a href="#">Camera/Classroom settings</a> -->
        <a href="logout.php">Logout</a>
    </div>
    <div class="main">
  <div class="container">
    <h2 style="color: Green;text-align: center;">View Attendance</h2><br>
  <form action="/action_page.php">
    <div class="row">
      <div class="column">
        <label for="fsname" id="SN">Subject</label>
      
        <select id="subject" name="subject" style="width:20%">
          <option value="none">--Select--</option>
          <option value="name1">BDA</option>
          <option value="name2">IOE</option>
          <option value="name3">ERP</option>
          <option value="name3">PM</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="column">
        <label for="msg"id="SN" style="padding: 20px;">Date</label>
        <input type="date" name="fdate">
        <label style="padding: 10px">To</label>
        <input type="date" name="ldate">
      </div>
    </div><br>
    <div class="row">
      <input type="submit" value="Generate Report" style="padding-left: 50px;">
    </div>
  </form><br><br>
  <div class="Table">
  <table class="table table-bordered">
    <tr>
      <th>Sr no.</th>
      <th>Student Name</th>
      <th>Moodle ID</th>
      <th>Present</th>
      <th>Absent</th>
      <th>Total lectures</th>
    </tr>
    <tr>
      <td>1.</td>
      <td>Jayesh Bhosale</td>
      <td>17104014</td>
      <td>15</td>
      <td>5</td>
      <td>20</td>
    </tr>
    <tr>
      <td>2.</td>
      <td>Tejas Bhanushali</td>
      <td>17104031</td>
      <td>14</td>
      <td>6</td>
      <td>20</td>
    </tr>
    <tr>
    <td>3.</td>
      <td>Yash Gangani</td>
      <td>18204009</td>
      <td>14</td>
      <td>6</td>
      <td>20</td>
    </tr>
  </table>
  </div><br>
  <center><button class="DR">Download Report</button></center>
  </div>
</div>


    <script>
      function openNav() {
        document.getElementById("Sidenav").style.width = "250px";
        document.getElementById("main").style.marginLeft = "250px";
        document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
      }
      
      function closeNav() {
        document.getElementById("Sidenav").style.width = "0";
        document.getElementById("main").style.marginLeft= "0";
        document.body.style.backgroundColor = "white";
      }
      </script>
      <script>
        var dropdown = document.getElementsByClassName("dropdown-btn");
        var i;

        for (i = 0; i < dropdown.length; i++) {
        dropdown[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var dropdownContent = this.nextElementSibling;
        if (dropdownContent.style.display === "block") {
        dropdownContent.style.display = "none";
        } else {
        dropdownContent.style.display = "block";
        }
        });
      }
      </script>   
  </body>
</html>
