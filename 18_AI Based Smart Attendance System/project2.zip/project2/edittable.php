<?php
$host="localhost";
$user="root";
$password="";
$datab="logindb";

$conn=mysqli_connect($host,$user,$password,$datab);
/*$connect = mysqli_connect("localhost", "root", "", "testing");*/
$query = "SELECT * FROM attendance";
$result = mysqli_query($conn, $query);
?>
<html>  
 <head>  
    <title>Live Table Data Edit Delete using Tabledit Plugin in PHP</title>  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>            
    <script src="jquery.tabledit.min.js"></script>
<style>
  /*table css*/
table td,th{
  border-collapse: collapse;
  border: 2px solid black;
}
table {
  width: 100%;
  border-collapse: collapse;
  background-color: white;
  text-align: center;
}
table th{
  background-color: green;
  text-align: center;
}
</style>

  </head>  
    <body>  
  <div class="container">  
   <br />  
   <br />  
   <br />  
            <div class="table-responsive">  
    <h3 align="center">Live Table Data Edit Delete using Tabledit Plugin in PHP</h3><br />  
    <table id="editable_table" class="table table-bordered table-striped">
      <tr>
        <th>Roll no.</th>
        <th>Student Name</th>
        <th>Moodle ID</th>
        <th>Date</th>
        <th>Timing</th>
        <th>Status</th>
      </tr>
     <tbody>
     <?php
     while($row = mysqli_fetch_array($result))
     {
      echo '
      <tr>
       <td>'.$row["rno"].'</td>
       <td>'.$row["sname"].'</td>
       <td>'.$row["moodle_id"].'</td>
       <td>'.$row["Date"].'</td>
       <td>'.$row["timing"].'</td>
       <td>'.$row["status"].'</td>
      </tr>
      ';
     }
     ?>
     </tbody>
    </table>
   </div>  
  </div>  
  <!--https://markcell.github.io/jquery-tabledit/#examples-->
 </body>  
</html>  
<!-- <?php  
//action.php
$host="localhost";
$user="root";
$password="";
$datab="logindb";

$conn=mysqli_connect($host,$user,$password,$datab);
/*$connect = mysqli_connect('localhost', 'root', '', 'testing');*/

$input = filter_input_array(INPUT_POST);

$s_name = mysqli_real_escape_string($conn, $input["sname"]);
$m_id = mysqli_real_escape_string($conn, $input["moodle_id"]);
$date = mysqli_real_escape_string($conn, $input["Date"]);
$timing = mysqli_real_escape_string($conn, $input["timing"]);
$status = mysqli_real_escape_string($conn, $input["status"]);

if($input["action"] === 'edit')
{
 $query = "UPDATE attendance SET sname = '".$s_name."', m_id = '".$moodle_id."', Date = '".$date."', timing = '".$timing."', status = '".$status."' WHERE rno = '".$input["rno"]."' ";

 mysqli_query($conn, $query);

}
if($input["action"] === 'delete')
{
 $query = "
 DELETE FROM attendance 
 WHERE rno = '".$input["rno"]."'
 ";
 mysqli_query($conn, $query);
}

echo json_encode($input);

?> -->

<script>  
$(document).ready(function(){  
     $('#editable_table').Tabledit({
      url:'action.php',
      deleteButton: false,

      buttons: {
        edit: {
            class: 'btn btn-sm btn-primary',
            html:'<span class="glyphicon glyphicon-pencil"></span> &nbsp EDIT',
            action: 'edit'
        }
    },

      columns:{
       identifier:[0, "rno"],
       editable:[[1, 'sname'], [2, 'moodle_id'], [3, 'Date'], [4, 'timing'], [5, 'status']]
      },
      restoreButton:false,
      /*onSuccess:function(data, textStatus, jqXHR)
      {
       if(data.action == 'delete')
       {
        $('#'+data.id).remove();
       }
      }*/

     });
 
});  
 </script>
