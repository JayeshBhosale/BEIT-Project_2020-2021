<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Contact Us</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<?php
session_start();

$host="localhost";
$user="root";
$password="";
$datab="logindb";

$conn=mysqli_connect($host,$user,$password,$datab);
#mysqli_select_db($datab);

if(isset($_POST['submit'])){
    $fname=$_POST['fname'];
    $Email=$_POST['Semail'];
    $subject=$_POST['subject'];
    $message=$_POST['msg'];
    
    $sql="insert into contactform values ('$fname','$Email','$subject','$message')";
    
    $result=mysqli_query($conn,$sql);

    if(mysqli_num_rows($result)==1){
        echo"<script>alert('Message send successfully!!!');window.location='contactus.php'</script>";
        #header("Location:aboutus.php");
        $_SESSION['username']= $Email;
    }
}
  ?>


<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}

.about-section {
  padding: 50px;
  text-align: center;
  background-color: #474e5d;
  color: white;
}

.container {
  padding: 0 16px;
  background-color: white;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

.dropdown {
  float: right;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 15px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.dropdown:hover .dropbtn {
  background-color: #4CAF50;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: black;
  color: white;
}

.dropdown:hover .dropdown-content {
  display: block;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}

/*contact us form style start */
/* Full-width input fields */
input[type=text]{
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
  font-size: 16px;
  color: darkblack;
}

/* Add a background color when the inputs get focus */
input[type=text]:focus{
  background-color: #ddd;
  outline: none;
}

/* Set a style for all buttons */
button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: center;
  width: 50%;
  font-size: 18px;
}

/* Add padding to container elements */
.container {
  padding: 16px;
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: #474e5d;
  padding-top: 50px;
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 40%; /* Could be more or less, depending on screen size */
}

/* Style the horizontal ruler */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}
 
/* The Close Button (x) */
.close {
  position: absolute;
  right: 35px;
  top: 15px;
  font-size: 40px;
  font-weight: bold;
  color: #f1f1f1;
}

.close:hover,
.close:focus {
  color: #f44336;
  cursor: pointer;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}


</style>
</head>
<body background="none">

<div class="navbar">
      <a class="active" href="example.php"><i class="fa fa-fw fa-home"></i> Home</a> 
      <!--<a href="#" ><i class="fa fa-fw fa-search"></i> Search</a>--> 
      <a href="aboutus.php" class="ab"><i class="fa fa-fw fa-user"></i> About us</a>
      <a href="contactus.php" class="con"><i class="fa fa-fw fa-envelope"></i> Contact us</a>



<div class="dropdown">
    <button class="dropbtn">Login 
      <i class="material-icons" style="font-size: 14px;">input</i>
    </button>
    <div class="dropdown-content">
      <a href="example.php">Admin</a>
      <a href="Faculty_login.php">Faculty</a>
      <a href="student_login.php">Student</a>
      <a href="Parents_login.php">Parents</a>
    </div>
  </div> 
</div>

<!--contact us form-->
  <form class="modal-content" action="contactus.php" method="POST">
    <div class="container">
      <center><h1>Contact Us</h1></center>
      <center><p></p></center>
      <hr>
      <label for="name"><b>Name</b></label>
      <input type="text" id="id01" placeholder="Enter full name" name="fname" required>

      <label for="Semail"><b>Email</b></label>
      <input type="text" id="id02" placeholder="Enter Email" name="Semail" required>

      <label for="Subject"><b>Subject</b></label>
      <input type="text" id="id03" name="subject" required>
      
      <label for="message"><b>Message</b></label><br>
      <textarea placeholder="" id="id04" name="msg" required style="height: 100px; width: 100%; font-size: 16px;"></textarea>


      <div class="clearfix">
       <!-- <button type="button" onclick= "clearfield()" class="cancelbtn">Cancel</button> -->
        <center><button type="submit" name="send" class="signupbtn">Send</button></center>
      </div>
    </div>
  </form>




<!--<script>
// Get the modal
function clearfield{
document.getElementById("id01").value = "";
}

</script>
-->

</body>
</html>