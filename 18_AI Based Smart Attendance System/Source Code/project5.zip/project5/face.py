import cv2,os
#from imutils.video import VideoCapture
import shutil
import pandas as pd
import datetime
import time
import shutil
import csv
import numpy as np
from PIL import Image, ImageTk
import pandas as pd
import datetime
import time
import imutils
#from main import name
def Takephoto(Id,name):
        name=name
        Id=Id
        print (name)
        print (Id)
        
    #if(is_number(Id) and name.isalpha()):
        #cam=cv2.imread('eg1.jpg')
        #imagepath ='\eg1.jpg'
        #cam=cv2.imread(imagepath)
        cam =   cv2.VideoCapture(0,cv2.CAP_DSHOW)#cv2.CAP_DSHOW
        
        harcascadePath = "haarcascade_frontalface_default.xml"
        detector=cv2.CascadeClassifier(harcascadePath)

        harcascadePath_eye="haarcascade_eye.xml"
        detector_eye=cv2.CascadeClassifier(harcascadePath_eye)
        harcascadePath_Profile = "haarcascade_profileface.xml"
        detector_profile=cv2.CascadeClassifier(harcascadePath_Profile)
        sampleNum=0
        while True :
            ret,img = cam.read()
            #ret,img = cv2.imread('eg3.jpg')
            img = imutils.resize(img, width=1050, height=500 )
            #img = cv2.resize(img, (0,0), (1680 , 1050),fx=1.0, fy=1.0 ,interpolation = cv2.INTER_CUBIC )
            #frame = cv2.imencode('.jpg', img)[1].tobytes()
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = detector.detectMultiScale(gray, scaleFactor=1.3,minNeighbors=4,minSize=(30, 30))
            #roi_gray = gray[y: y+h, x: x+w]
            #roi_color = img[y: y+h, x: x+w]
            eyes = detector_eye.detectMultiScale (gray,scaleFactor=1.3,minNeighbors=4,minSize=(30, 30))
            profile_faces = detector_profile.detectMultiScale(gray, scaleFactor=1.3,minNeighbors=4,minSize=(30, 30))
            
            
            print (faces)
            for (x,y,w,h) in faces:
                    #frame = cv2.imencode('.jpg', img)[1].tobytes()
                    cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
                   
                    for (ex, ey, ew, eh) in eyes:
                        cv2.rectangle(img,(ex,ey),(ex+ew,ey+eh),(0,0,255),2)
                        #roi_color = cv2.flip (roi_color, 1)
                        #return roi_color
                    for (px,py,pw,ph) in profile_faces:
                        #frame = cv2.imencode('.jpg', img)[1].tobytes()
                        cv2.rectangle(img,(px,py),(px+pw,py+ph),(255,0,0),2)
                        
                         
                    #incrementing sample number 
                    sampleNum=sampleNum+1
                    #saving the captured face in the dataset folder TrainingImage
                    cv2.imwrite("TrainingImage\ "+name +"."+Id +'.'+ str(sampleNum) + ".jpg", gray[y:y+h,x:x+w])
                    #cv2.imwrite("TrainingImage\ " +str(sampleNum) + ".jpg", gray[y:y+h,x:x+w])
                    #display the frame
                    
                    cv2.imshow('frame',img)
                    
                
            if cv2.waitKey(200) & 0xFF == ord('q'):
                time.sleep(2.0)
               
                
                break
                    # break if the sample number is morethan 100
            elif sampleNum>60:
                
                break
            
        
        
           
          
        cam.release()
        cv2.destroyAllWindows() 
        res = print("Images Saved for ID : " + Id +" Name : "+ name)
        row = [Id , name]
        print (row)
       
        #return frame
        with open('StudentDetails\StudentDetails.csv','a+') as csvFile:
            writer = csv.writer(csvFile)
            writer.writerow(row)
        csvFile.close()
        frame = cv2.imencode('.jpg', img)[1].tobytes()
        return frame
        #frame = cv2.imencode('.jpg', img)[1].tobytes()
       

def TrackImages():
    recognizer = cv2.face.LBPHFaceRecognizer_create()#cv2.createLBPHFaceRecognizer()
    recognizer.read("TrainingImageLabel\Trainner.yml")
    harcascadePath = "haarcascade_frontalface_default.xml"
    faceCascade = cv2.CascadeClassifier(harcascadePath);
    harcascadePath_eye = "haarcascade_eye.xml"
    eyeCascade = cv2.CascadeClassifier(harcascadePath_eye);
    profile_harcascadePath = "haarcascade_profileface.xml"
    profile_faceCascade = cv2.CascadeClassifier(profile_harcascadePath);    
    df=pd.read_csv("StudentDetails\StudentDetails.csv")
    cam = cv2.VideoCapture(0,cv2.CAP_DSHOW)
    #cam=cv2.imread('eg1.jpg',0)
    font = cv2.FONT_HERSHEY_SIMPLEX        
    col_names =  ['Id','Name','Date','Time']
    attendance = pd.DataFrame(columns = col_names)    
    while True:
        ret, im =cam.read()
        im = imutils.resize(im, width=1500, height=700 )
        #im = cv2.resize(im, (0,0), fx=1.5, fy=1.0)
        gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
        faces=faceCascade.detectMultiScale(gray, scaleFactor=1.3,minNeighbors=4,minSize=(30, 30)) 
        eyes = eyeCascade.detectMultiScale (gray,scaleFactor=1.3,minNeighbors=4,minSize=(30, 30))
        pfaces=profile_faceCascade.detectMultiScale(gray, scaleFactor=1.3,minNeighbors=4,minSize=(30, 30))
               
        for(x,y,w,h) in faces:
            cv2.rectangle(im,(x,y),(x+w,y+h),(225,0,0),2)
            Id, conf = recognizer.predict(gray[y:y+h,x:x+w])
            for (ex, ey, ew, eh) in eyes:
                        cv2.rectangle(im,(ex,ey),(ex+ew,ey+eh),(0,0,255),2) 
            for (px,py,pw,ph) in pfaces:
                        #frame = cv2.imencode('.jpg', img)[1].tobytes()
                        cv2.rectangle(im,(px,py),(px+pw,py+ph),(255,0,0),2)                                  
            if(conf < 50):
                ts = time.time()      
                date = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
                timeStamp = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
                aa=df.loc[df['Id'] == Id]['Name'].values
                tt=str(Id)+"-"+aa
                attendance.loc[len(attendance)] = [Id,aa,date,timeStamp]
                
            else:
                Id='Unknown'                
                tt=str(Id)  
            if(conf > 75):
                noOfFile=len(os.listdir("ImagesUnknown"))+1
                cv2.imwrite("ImagesUnknown\Image"+str(noOfFile) + ".jpg", im[y:y+h,x:x+w])            
            cv2.putText(im,str(tt),(x,y+h), font, 1,(255,255,255),2)        
        attendance=attendance.drop_duplicates(subset=['Id'],keep='first')    
        cv2.imshow('im',im) 
        
        if (cv2.waitKey(1)==ord('q')):
            break
        frame = cv2.imencode('.jpg', im)[1].tobytes()
        return frame
    ts = time.time()      
    date = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
    timeStamp = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
    Hour,Minute,Second=timeStamp.split(":")
    fileName="Attendance\Attendance_"+date+"_"+Hour+"-"+Minute+"-"+Second+".csv"
    attendance.to_csv(fileName,index=False)
    cam.release()
    cv2.destroyAllWindows()
    #frame = cv2.imencode('.jpg', im)[1].tobytes()
    #return frame
    #print(attendance)
    #res=attendance
    #message2.configure(text= res)

