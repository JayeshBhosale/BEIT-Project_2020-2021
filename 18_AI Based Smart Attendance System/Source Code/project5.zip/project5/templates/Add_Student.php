<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Add Student</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="sidebar.css">
    <link rel="stylesheet" href="{{ url_for('static',filename='sidebar.css') }}" >
    <!--<link rel="stylesheet" href="{{ url_for('static',filename='sidebar1.css') }}" >-->
    <link rel="stylesheet" href="{{ url_for('static',filename='style.css') }}" >
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  </head>
  <body>
    <div id="Sidenav" class="sidebar">

      
      <!--<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>-->
        <a class="active" href="#">E-Attendence</a>
        <button class="dropdown-btn">Registration 
          <i class="fa fa-caret-down"></i>
        </button>
        <div class="dropdown-container">
          <button class="dropdown-btn">Add Students 
            <i class="fa fa-caret-down" ></i>
          </button>
          <div class="dropdown-container">
            <a href="#">Register Student</a>
            <a href="#">Face Enrollment</a>
          </div>
          <a href="Add_Parents.php">Add Parents</a>
          <a href="#">Add Faculty</a>
        </div>

        <a href="Schedule_Lec_Admin.php">Schedule Lectures</a>
        <a href="#">View Attendence</a>
        <a href="#">Camera/Classroom settings</a>
        <!-- Logout Button Code-->
        <a href="logout.php">Logout</a>

    </div>

    <div id="main" style="padding-left: 200px;">
       
      <!--<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span> -->

    <center>

    <h2>Add Student's</h2>
    <br>
    <br>
    
    <div class="container">
      <form method="POST" action='/video_feed'>
        <div class="row">
          <div class="col-25">
            <label for="name">Student Name</label>
          </div>
          <div class="col-75">
            <input type="text" id="name" name="name" placeholder="Student name..">
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label for="parentsname">Parent's Name</label>
          </div>
          <div class="col-75">
            <input type="text" id="parentsname" name="parentsname" placeholder="Parent's name..">
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label for="moodle">Moodle Id</label>
          </div>
          <div class="col-75">
            <input type="text" id="moodle" name="moodle" placeholder="Enter Moodle Id..">
          </div>
        </div>
        <div class="row">
            <div class="col-25">
              <label for="rollnb">Roll Number</label>
            </div>
            <div class="col-75">
              <input type="text" id="rollnb" name="rollnb" placeholder="Roll Number..">
            </div>
          </div>
        <div class="row">
            <div class="col-25">
              <label for="branch">Class</label>
            </div>
            <div class="col-75">
            <select id="catogery" name="catogery">
              <option value="FE">FE</option>
              <option value="SE">SEIT</option>
              <option value="TE">TEIT</option>
              <option value="BE">BEIT</option>
            </select>
          </div>
          </div>
        <div class="row">
          <div class="col-25">
            <label for="division">Division</label>
          </div>
          <div class="col-75">
            <select id="division" name="division">
              <option value="A">A</option>
              <option value="B">B</option>
            </select>
          </div>
        </div>

        <div class="row">
            <div class="col-25">
              <label for="mobilenb">Mobile Number</label>
            </div>
            <div class="col-75">
              <input type="text" id="mobilenum" name="mobilenum" placeholder="Mobile Number..">
            </div>
          </div>

        <div class="row">
            <div class="col-25">
              <label for="parentsnb">Parent's Mobile Number</label>
            </div>
            <div class="col-75">
              <input type="text" id="nbp" name="nbp" placeholder="Parent's Mobile number..">
            </div>
        </div><br><hr><br>

        
        
        <div class="row">
          <div class='col-85'>
          <center>
          <input type="submit" class="btn" value="Submit" action="/video_feed" ><center>
      </div>
        </div><br><hr><br>
        
  </form>
      <form method='POST' action="/track">
      <div class="row">
          <div class='col-85'>
          <center><input type="submit" class="btn" value="Track attendance" action="/track" ></center>
      </div>
        </div>
        </form><br><hr><br>
<form method='POST' action="/trackmulti">
      <div class="row">
          <div class='col-85'>
          <center><input type="submit" class="btn" value="Track multiple " action="/trackmulti" ></center>
      </div>
        </div>
        </div>
        

</form>
      
    
  <!--  <div class="row">
            <div class="col-25">
                <label for="uploadimage">Upload Image</label>
            </div>
            <div class="col-75">
                <input type="file" id="uploadimage" name="uploadimage">
                <button class="button button4" input type="submit">Upload</button>
            </div>
        </div>
        <br>
        <br>
        OR
        <br>
        <br>
        <div class="row">
            <div class="col-25">
                <label for="uploadimage">Upload bulk file</label>
            </div>
            <div class="col-75">
                <input type="file" id="uploadfile" name="uploadfile">
                <button class="button button4" input type="submit">Upload</button>
            </div>
        </div>
    </center>
  </div>  --> 


    <!--<script>
      function openNav() {
        document.getElementById("Sidenav").style.width = "250px";
        document.getElementById("main").style.marginLeft = "250px";
        document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
      }
      
      function closeNav() {
        document.getElementById("Sidenav").style.width = "0";
        document.getElementById("main").style.marginLeft= "0";
        document.body.style.backgroundColor = "white";
      }
      </script>-->
      <!--<script>
        var dropdown = document.getElementsByClassName("dropdown-btn");
        var i;

        for (i = 0; i < dropdown.length; i++) {
        dropdown[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var dropdownContent = this.nextElementSibling;
        if (dropdownContent.style.display === "block") {
        dropdownContent.style.display = "none";
        } else {
        dropdownContent.style.display = "block";
        }
        });
      }
      </script>  --> 
  </body>
</html>
