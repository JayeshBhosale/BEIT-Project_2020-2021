#!/usr/bin/env python
from flask import Flask, render_template, Response ,request,redirect
#from face import Takephoto,TrackImages
from flask_mysqldb import MySQL
import time
import cv2,os
import shutil
import csv
import numpy as np
from PIL import Image
import pandas as pd
import datetime
import time
import imutils
import schedule
import time
import mysql.connector as mysql
import mysql.connector as sql_db 
app = Flask(__name__)
############################# Database ###############################
app.config ['MYSQL_HOST']='localhost'
app.config ['MYSQL_USER']='root'
app.config ['MYSQL_Password']=''
app.config ['MYSQL_DB']='attendance_system'
mysql=MySQL(app)
@app.route('/' , methods=['POST','GET'])
def index():
     return render_template('Add_Student.php')

def Takephoto(moodle,rollnb,name,parentsname,batch,division,mobnb,parentsnb):
    #frame = Takephoto(Id,name)
        
        Id=moodle
        rollnb=rollnb
        Name=name
        parentsname=parentsname
        batch=batch
        division=division
        mobnb=mobnb
        parentsnb=parentsnb
        
        cam =   cv2.VideoCapture(0,cv2.CAP_DSHOW)#cv2.CAP_DSHOW
        harcascadePath = "haarcascade_frontalface_default.xml"
        detector=cv2.CascadeClassifier(harcascadePath)
        harcascadePath_eye="haarcascade_eye.xml"
        detector_eye=cv2.CascadeClassifier(harcascadePath_eye)
        harcascadePath_Profile = "haarcascade_profileface.xml"
        detector_profile=cv2.CascadeClassifier(harcascadePath_Profile)
        sampleNum=0
        while True :
            ret,img = cam.read()
            #ret,img = cv2.imread('eg3.jpg')
            img = imutils.resize(img, width=1050, height=500 )
            #img = cv2.resize(img, (0,0), (1680 , 1050),fx=1.0, fy=1.0 ,interpolation = cv2.INTER_CUBIC )
            #frame = cv2.imencode('.jpg', img)[1].tobytes()
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = detector.detectMultiScale(gray, scaleFactor=1.3,minNeighbors=4,minSize=(30, 30))
            #roi_gray = gray[y: y+h, x: x+w]
            #roi_color = img[y: y+h, x: x+w]
            eyes = detector_eye.detectMultiScale (gray,scaleFactor=1.3,minNeighbors=4,minSize=(30, 30))
            profile_faces = detector_profile.detectMultiScale(gray, scaleFactor=1.3,minNeighbors=4,minSize=(30, 30))
            print (faces)
            for (x,y,w,h) in faces:
                    #frame = cv2.imencode('.jpg', img)[1].tobytes()
                    cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
                   
                    for (ex, ey, ew, eh) in eyes:
                        cv2.rectangle(img,(ex,ey),(ex+ew,ey+eh),(0,0,255),2)
                        #roi_color = cv2.flip (roi_color, 1)
                        #return roi_color
                    for (px,py,pw,ph) in profile_faces:
                        #frame = cv2.imencode('.jpg', img)[1].tobytes()
                        cv2.rectangle(img,(px,py),(px+pw,py+ph),(255,0,0),2)
                        
                         
                    #incrementing sample number 
                    sampleNum=sampleNum+1
                    #saving the captured face in the dataset folder TrainingImage
                    cv2.imwrite("TrainingImage\ "+name +"."+moodle +'.'+ str(sampleNum) + ".jpg", gray[y:y+h,x:x+w])
                    
                    #cv2.imwrite("TrainingImage\ " +str(sampleNum) + ".jpg", gray[y:y+h,x:x+w])
                    #display the frame
                    
                    cv2.imshow('frame',img)
                    
            frame = cv2.imencode('.jpg', img)[1].tobytes()
            yield (b'--frame\r\n'
                    b'Content-Type: image/jpg\r\n\r\n' + frame + b'\r\n')   
            if cv2.waitKey(200) & 0xFF == ord('q'):
                time.sleep(2.0)
               
                
                break
                    # break if the sample number is morethan 100
            elif sampleNum>60:
                
                break
        
        cam.release()
        cv2.destroyAllWindows() 
        res = print("Images Saved for ID : " + moodle +" Name : "+ name)
        row = [Id,rollnb,name,parentsname,batch,division,mobnb,parentsnb]
        print (row)
       
        #return frame
        with open('StudentDetails\StudentDetails.csv','a+') as csvFile:
            writer = csv.writer(csvFile)
            writer.writerow(row)
        csvFile.close()
        print('train')
        recognizer = cv2.face_LBPHFaceRecognizer.create()
        harcascadePath = "haarcascade_frontalface_default.xml"
        detector =cv2.CascadeClassifier(harcascadePath)
        faces,Id = getImagesAndLabels("TrainingImage")
        recognizer.train(faces, np.array(Id))
        recognizer.save("TrainingImageLabel\Trainner.yml")
def getImagesAndLabels(path):
    #get the path of all the files in the folder
    imagePaths=[os.path.join(path,f) for f in os.listdir(path)] 
    print(imagePaths)
    
    #create empth face list
    faces=[]
    #create empty ID list
    Ids=[]
    #now looping through all the image paths and loading the Ids and the images
    for imagePath in imagePaths:
        #loading the image and converting it to gray scale
        pilImage=Image.open(imagePath).convert('L')
        #Now we are converting the PIL image into numpy array
        imageNp=np.array(pilImage,'uint8')
        #getting the Id from the image
        Id=int(os.path.split(imagePath)[-1].split(".")[1])
        # extract the face from the training image sample
        faces.append(imageNp)
        Ids.append(Id)        
    return faces,Ids
    
                
                    

def TrackImages():
    #while True:
       # frame = TrackImages()
    recognizer = cv2.face.LBPHFaceRecognizer_create()#cv2.createLBPHFaceRecognizer()
    recognizer.read("TrainingImageLabel\Trainner.yml")
    harcascadePath = "haarcascade_frontalface_default.xml"
    faceCascade = cv2.CascadeClassifier(harcascadePath);
    harcascadePath_eye = "haarcascade_eye.xml"
    eyeCascade = cv2.CascadeClassifier(harcascadePath_eye);
    profile_harcascadePath = "haarcascade_profileface.xml"
    profile_faceCascade = cv2.CascadeClassifier(profile_harcascadePath);    
    df=pd.read_csv("StudentDetails\StudentDetails.csv")
    cam = cv2.VideoCapture(0,cv2.CAP_DSHOW)
    #cam = cv2.VideoCapture('trial.mp4',0)
    #cam=cv2.imread('20201114_230358.jpg')
    font = cv2.FONT_HERSHEY_SIMPLEX        
    col_names =  ['Id','Name','Date','Time']
    attendance = pd.DataFrame(columns = col_names)
       
    while True:
        ret, im =cam.read()
        #ret,im = cv2.imread('eg1.jpg')
        im = imutils.resize(im, width=1000, height=900 )
        #im = cv2.resize(im, (0,0), fx=1.5, fy=1.0)
        gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
        faces=faceCascade.detectMultiScale(gray, scaleFactor=1.3,minNeighbors=4,minSize=(30, 30)) 
        eyes = eyeCascade.detectMultiScale (gray,scaleFactor=1.3,minNeighbors=4,minSize=(30, 30))
        pfaces=profile_faceCascade.detectMultiScale(gray, scaleFactor=1.3,minNeighbors=4,minSize=(30, 30))
               
        for(x,y,w,h) in faces:
            cv2.rectangle(im,(x,y),(x+w,y+h),(225,0,0),2)
            Id, conf = recognizer.predict(gray[y:y+h,x:x+w])
            for (ex, ey, ew, eh) in eyes:
                        cv2.rectangle(im,(ex,ey),(ex+ew,ey+eh),(0,0,255),2) 
            for (px,py,pw,ph) in pfaces:
                        #frame = cv2.imencode('.jpg', img)[1].tobytes()
                        cv2.rectangle(im,(px,py),(px+pw,py+ph),(255,0,0),2)                                  
            if(conf < 50):
                ts = time.time()      
                date = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
                timeStamp = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
                aa=df.loc[df['Id'] == Id]['Name'].values
                tt=str(Id)+"-"+aa
                attendance.loc[len(attendance)] = [Id,aa,date,timeStamp]
                result=(Id,aa,date,timeStamp)
                print(result)
                
                
            else:
                Id='Unknown'                
                tt=str(Id)  
            if(conf > 75):
                noOfFile=len(os.listdir("ImagesUnknown"))+1
                cv2.imwrite("ImagesUnknown\Image"+str(noOfFile) + ".jpg", im[y:y+h,x:x+w])            
            cv2.putText(im,str(tt),(x,y+h), font, 1,(255,255,255),2)        
        attendance=attendance.drop_duplicates(subset=['Id'],keep='first')    
        cv2.imshow('im',im)
        frame = cv2.imencode('.jpg', im)[1].tobytes() 
        yield (b'--frame\r\n'
                        b'Content-Type: image/jpg\r\n\r\n' + frame + b'\r\n')
        #time.sleep(0.1)
        if (cv2.waitKey(1)==ord('q')):
            break
        
        #return frame
    ts = time.time()      
    date = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
    timeStamp = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
    Hour,Minute,Second=timeStamp.split(":")
    fileName="Attendance\Attendance.csv"
    attendance.to_csv(fileName,index=False)
    cam.release()
    cv2.destroyAllWindows()
    
    conn = sql_db.connect( host='localhost', database='attendance_system', user='root', password='') 
    #mydb=mysql.connector.connect(host="localhost",user="root",password='',database='trialcsv')
    print('database connected')
    
    cur1=conn.cursor()
    file = open('Attendance\Attendance.csv')
    csv_reader = csv.reader(file)
    next(csv_reader)

    for row in csv_reader:
        print(row)
        sql=('INSERT INTO attendance_info(Id,Name,Date,Time) VALUES (%s,%s,%s,%s) ' )
        cur1.execute(sql,row)
        #print(row)
    conn.commit()
    cur1.close()
    print('add')
        
def trackmimages():
    #while True:
       # frame = TrackImages()
    recognizer = cv2.face.LBPHFaceRecognizer_create()#cv2.createLBPHFaceRecognizer()
    recognizer.read("TrainingImageLabel\Trainner.yml")
    harcascadePath = "haarcascade_frontalface_default.xml"
    faceCascade = cv2.CascadeClassifier(harcascadePath);
    harcascadePath_eye = "haarcascade_eye.xml"
    eyeCascade = cv2.CascadeClassifier(harcascadePath_eye);
    profile_harcascadePath = "haarcascade_profileface.xml"
    profile_faceCascade = cv2.CascadeClassifier(profile_harcascadePath);    
    df=pd.read_csv("StudentDetails\StudentDetails.csv")
    #cam = cv2.VideoCapture(0,cv2.CAP_DSHOW)
    cam = cv2.VideoCapture('eg4.mp4',0)
    #cam=cv2.imread('20201114_230358.jpg')
    font = cv2.FONT_HERSHEY_SIMPLEX        
    col_names =  ['Id','Name','Date','Time']
    attendance = pd.DataFrame(columns = col_names)
       
    while True:
        ret, im =cam.read()
        #ret,im = cv2.imread('eg1.jpg')
        im = imutils.resize(im, width=1000, height=900 )
        #im = cv2.resize(im, (0,0), fx=1.5, fy=1.0)
        gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
        faces=faceCascade.detectMultiScale(gray, 1.1,1) 
        eyes = eyeCascade.detectMultiScale (gray, 1.2,2)
        pfaces=profile_faceCascade.detectMultiScale(gray, 1.2,2)
               
        for(x,y,w,h) in faces:
            cv2.rectangle(im,(x,y),(x+w,y+h),(225,0,0),2)
            Id, conf = recognizer.predict(gray[y:y+h,x:x+w])
            for (ex, ey, ew, eh) in eyes:
                        cv2.rectangle(im,(ex,ey),(ex+ew,ey+eh),(0,0,255),2) 
            for (px,py,pw,ph) in pfaces:
                        #frame = cv2.imencode('.jpg', img)[1].tobytes()
                        cv2.rectangle(im,(px,py),(px+pw,py+ph),(255,0,0),2)                                  
            if(conf < 50):
                ts = time.time()      
                date = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
                timeStamp = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
                aa=df.loc[df['Id'] == Id]['Name'].values
                tt=str(Id)+"-"+aa
                attendance.loc[len(attendance)] = [Id,aa,date,timeStamp]
                result=(Id,aa,date,timeStamp)
                print(result)
                
                
            else:
                Id='Unknown'                
                tt=str(Id)  
            if(conf > 75):
                noOfFile=len(os.listdir("ImagesUnknown"))+1
                cv2.imwrite("ImagesUnknown\Image"+str(noOfFile) + ".jpg", im[y:y+h,x:x+w])            
            cv2.putText(im,str(tt),(x,y+h), font, 1,(255,255,255),2)        
        attendance=attendance.drop_duplicates(subset=['Id'],keep='first')    
        cv2.imshow('im',im)
        frame = cv2.imencode('.jpg', im)[1].tobytes() 
        yield (b'--frame\r\n'
                        b'Content-Type: image/jpg\r\n\r\n' + frame + b'\r\n')
        #time.sleep(0.1)
        if (cv2.waitKey(1)==ord('q')):
            break
        
        #return frame
    ts = time.time()      
    date = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
    timeStamp = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
    Hour,Minute,Second=timeStamp.split(":")
    fileName="Attendance\Attendance.csv"
    attendance.to_csv(fileName,index=False)
    cam.release()
    cv2.destroyAllWindows()

    conn = sql_db.connect( host='localhost', database='attendance_system', user='root', password='') 
    #mydb=mysql.connector.connect(host="localhost",user="root",password='',database='trialcsv')
    print('database connected')
    
    cur1=conn.cursor()
    file = open('Attendance\Attendance.csv')
    csv_reader = csv.reader(file)
    next(csv_reader)

    for row in csv_reader:
        print(row)
        sql=('INSERT INTO attendance_info(Id,Name,Date,Time) VALUES (%s,%s,%s,%s) ' )
        cur1.execute(sql,row)
        #print(row)
    conn.commit()
    cur1.close()
    print('add')
          
@app.route('/video_feed', methods=['POST','GET'])

def video_feed():
    
    
    while True:
        if request.method == 'POST':
            
            moodle=request.form['moodle']
            rollnb=request.form['rollnb']
            name = request.form["name"]
            parentsname=request.form['parentsname']
            batch=request.form['catogery']
            division=request.form['division']
            mobnb=request.form['mobilenum']
            parentsnb=request.form['nbp']

            print(name,parentsname,moodle,batch,division,mobnb,parentsnb)
            print(name)

            cur=mysql.connection.cursor()
            cur.execute('INSERT INTO student_information(Moodle_Id,Roll_nb,Student_Name,Parents_Name,Class,Division,Mobile_nb,Parents_nb) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)',(moodle,rollnb,name,parentsname,batch,division,mobnb,parentsnb))
            mysql.connection.commit()
                    #time.sleep(0.2)        
            return Response(Takephoto(moodle,rollnb,name,parentsname,batch,division,mobnb,parentsnb),
                        mimetype='multipart/x-mixed-replace; boundary=frame')
    
@app.route('/track', methods=['POST','GET'])
def track():
        if request.method == 'POST':
            #cur = mysql.connection.cursor()
            #print('cur connected')
            
            return Response(TrackImages(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')
@app.route('/trackmulti', methods=['POST','GET'])
def trackmulti():
        if request.method == 'POST':
            #cur = mysql.connection.cursor()
            #print('cur connected')
            
            return Response(trackmimages(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

app.run( debug=True)