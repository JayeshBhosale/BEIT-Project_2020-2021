<?php
session_start();

$host="localhost";
$user="root";
$password="";
$datab="logindb";

$conn=mysqli_connect($host,$user,$password,$datab);
#mysqli_select_db($datab);

if(isset($_POST['submit'])){
    $uname_S=$_SESSION['uname'];
    $password=$_POST['psw'];
    //$sql="update parents_login set p_passwd=$password where p_email=$Emailp";
    $sql="update student_login SET s_passwd='$password' WHERE s_uname='$uname_S' limit 1";
    $result=mysqli_query($conn,$sql);
    if($result){
        echo"<script>alert('Password change successfully!!!'); window.location='student_login.php'</script>";
        #header("Location:aboutus.php");
    }
    else{
        echo"<script>alert('Something is Wrong!!!'); window.location='Studentnew_pass.php'</script>";
    }
}
    ?>

<!DOCTYPE html> 
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>New Password</title>
</head> 
<style> 
    /*set border to the form*/
      
    form { 
        /*padding-top: 50%;
        border: 3px solid #f1f1f1;*/
        padding-left: 35%;
        padding-top: 14%;
        position: center;
        height: 200px;
        width: 400px;
    } 
    /*assign full width inputs*/ 
      
    input[type=text], 
    input[type=password] { 
        width: 100%; 
        padding: 12px 20px; 
        margin: 8px 0; 
        display: inline-block; 
        border: 1px solid #ccc; 
        box-sizing: border-box; 
        color: red;
        background-color: white;
        font-size: 16px;
        size: 16px;
    } 
    /*set a style for the buttons*/ 
      
    button { 
        background-color: #4CAF50; 
        color: white; 
        padding: 14px 20px; 
        margin: 8px 0; 
        border: none; 
        cursor: pointer; 
        width: 100%; 
        font-size: 16px;
    } 
    /* set a hover effect for the button*/ 
      
    button:hover { 
        opacity: 0.8;
        background-color: #3399ff; 
    } 
      
    /*set padding to the container*/ 
      
    .container { 
        padding-left: 35%;
        position: center;
        padding: 16px; 
        border: 1px solid;
        background: rgb(0, 0, 0);
        background: rgba(0, 0, 0, 0.5);

    } 

.np{
    /*border: 3px solid #0080ff;
    background-color: #3399ff;*/
    color: white;
    height: 35px;

}

    /*set the forgot password text*/ 
      
    span.psw { 
        float: right; 
        padding-top: 16px; 
        font-size: 16px;
        color: #f1f1f1;


    } 

    #myInput{
        size: 16px;
    }
    /*set styles for span and cancel button on small screens*/ 
      
    @media screen and (max-width: 300px) { 
        span.psw { 
            display: block; 
            float: none; 
        } 
    } 
</style> 
  
<body class="bstyle"> 
    <form action="Studentnew_pass.php" style="padding-left: 35%;" method="POST">  
        <div class="container"> 
            <center><h2 class="np">New Password</h2></center>
            <!--<input type="text" placeholder="Email" name="email_p" required>-->   
            <input type="password" placeholder="Enter New Password" name="psw" id="myInput" required> 
  
            <button type="submit" name="submit">Change Password</button> 
            <input type="checkbox" onclick="myFunction()"> <label style="color: red; font-size: 18px">Show Password </label>
        </div> 
    </form> 
  
</body> 
  
<script>
function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>

</html> 