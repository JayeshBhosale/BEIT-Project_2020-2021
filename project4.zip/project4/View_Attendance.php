<!DOCTYPE html>
<html>
<head>
<title>View Attendance</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<style>
body {
  font-family: "Lato", sans-serif;
  background-image: url(idol.jpg);
  background-repeat: no-repeat;
  background-size: cover;
}

/* Fixed sidenav, full height */
.sidenav {
  height: 100%;
  width: 200px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  
}

/* Style the sidenav links and the dropdown button */
.sidenav a, .dropdown-btn {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
  border: none;
  background: none;
  width: 100%;
  text-align: left;
  cursor: pointer;
  outline: none;
}

/* On mouse-over */
.sidenav a:hover{
  color: #f1f1f1;
  background-color: #555;
}

/* Main content */
.main {
  margin-left: 200px; /* Same as the width of the sidenav */
  /*font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

/* Add an active class to the active dropdown button*/ 
.active {
  background-color: green;
  color: white;
}


/* Dropdown container (hidden by default). Optional: add a lighter background color and some left padding to change the design of the dropdown content */
.dropdown-container {
  display: none;
  background-color: #262626;
  padding-left: 8px;
}

/* Optional: Style the caret down icon */
.fa-caret-down {
  float: right;
  padding-right: 52px;
}

/* Add Student Dropdown*/
#adds{ padding-left: 6px; }
#adds:hover{
  color: white;
  background-color: none;
}

#addsDW{
  padding-right: 34px;
}

/*Notification Icon*/
.notification {
  background-color: #555;
  color: white;
  text-decoration: none;
  padding: 8px 8px;
  position: relative;
  display: inline-block;
  border-radius: 90px;
}

.notification:hover {
  background: red;
}

.badge {
  top: 42px;
  left: 144px;
  right:38px;
  width: 18px;
  height: 18px;
  /*padding: 2px 2px;*/
  display: flex;
  border-radius: 50%;
  background-color: red;
  color: white;
  position: absolute;
  align-items: center;
  justify-content: center;
  font-size: 15px;
}

.columnB{
  margin: 5px 20px 5px 0;
  float: left;
}

.columnS{
  margin: 5px 20px 5px 0;
  float: left;
}

.columnSU{
  margin: 5px 20px 5px 0;
  float: left;
  
}

.selectb{
  width:150px;
  height: 40px; 
  vertical-align: center;
  text-align: center;
  cursor:pointer;
}


.selectS{
  width:150px;
  height: 40px; 
  vertical-align: center;
  text-align: center;
  cursor:pointer;
}

.selectSB{
  width:150px;
  height: 40px; 
  vertical-align: center;
  text-align: center;
  cursor:pointer;
}

option{
  cursor:pointer;
}

@media screen and (max-width: 700px) {
  .sidenav {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidenav a {float: left;}
  div.content {margin-left: 0;}
  .sidenav .fa-caret-down {
  float: right;
  /*padding-left: 10px;*/
  padding-right: 310px;
  
}
.main {
  margin-left: 5px; /* Same as the width of the sidenav */
  /*font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
  
}

#addsDW{
  padding-right: 306px;
}

.columnB{
  width: 100%;
  flex-direction: column;
  align-items: stretch;
}

.columnS{
  width: 100%;
  flex-direction: column;
  align-items: stretch;
}

.columnSB{
  width: 100%;
  flex-direction: column;
  align-items: stretch;
  
}
}/*media screen bracket close*/

/*Container style*/
* {
  box-sizing: border-box;
}

input[type=text], select, textarea {
  width: 40%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
  color: white;
  font-size: 18px;
}

input[type=submit] {
  background-color: #448ee4;
  color: white;
  width: 150px;
  height: 40px;
  font-size: 15px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  position: relative;
  
}

input[type=submit]:hover {
  background-color: #4CAF50;
}

.container {
  border-radius: 5px;
  background-color: transparent;
  padding: 20px;
  opacity: 0.9;
}


/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

#SN{
  
  padding: 10px;
}

/*table css*/
table td,th{
  border-collapse: collapse;
  border: 2px solid black;
}
table {
  width: 100%;
  border-collapse: collapse;
  background-color: white;
  text-align: center;
}
table th{
  background-color: green;
}

/*Download Report button CSS*/
.DR{
  color: white;
  width: 150px;
  height: 40px;
  font-size: 15px;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  position: relative;
  background-color: #448ee4;
}
.DR:hover{
  background-color: #4CAF50;
}
</style>

<script>
  function populate(s1,s2)
  {
    var s1 = document.getElementById(s1);
    var s2 = document.getElementById(s2);
    s2.innerHTML = "";

    if(s1.value==="sem3")
    {
      var optionArray= ['all|All Subject','mathII|Applied MathsIII','ld|Logic Design','dsa|DSA','dbms|DBMS','poc|POC','ddl|Digital Design Lab','dsl|Data Structure Lab','sql|SQL Lab','jpl|Java Programming Lab'];
    }
    else if(s1.value==="sem4")
    {
      var optionArray= ['all|All Subject','mathIV|Applied MathsIV','cn|Computer Network','os|Operating Systems','coa|COA','at|Automata Theory','nl|Networking Lab','ul|Unix Lab','mpl|MPL','pl|Python Lab'];
    }
    else if(s1.value==="sem5")
    {
      var optionArray= ['all|All Subject','mep|MEP','ip|Internet Programming','admt|ADMT','cns|CNS','ecom|E-Commerce','cgvr|CGVR','ipl|IPL','sl|Security Lab','olab|OLAP Lab','iot|IOT Lab','bce|BCE'];
    }
    else if(s1.value==="sem6")
    {
      var optionArray= ['all|All Subject','sepm|SEPM','dmbi|DMBI','ccs|CCS','wn|WN','aip|AIP','df|DF','sdl|Software Design Lab','bil|BIL','csdl|Cloud Service Design Lab','snl|Sensor Network Lab','mp|Mini Project'];
    }
    else if(s1.value==="sem7")
    {
      var optionArray= ['all|All Subject','end|Enterprise Network Design','is|Infrastructure Security','ai|Artificial Intelligence','mad|MAD','stqa|STQA','csl|Cyber Security and Law','mis|Management Information System','ndl|Network Design Lab','asl|Advanced Security Lab','isl|Intelligence System Lab','aadl|AADL','p1|Project-I'];
    }
    else if(s1.value==="sem8")
    {
      var optionArray= ['all|All Subject','bda|BDA','ioe|IOE','erp|ERP','uid|UID','pm|Project Management','evm|Environmental Management','bdl|Big Data Lab','ioel|IOE Lab','dl|DevOps Lab','rpl|R Programming Lab','p2|Project-II'];
    }

    for(var option in optionArray){
      var pair = optionArray[option].split("|");
      var newOption = document.createElement("option");
      newOption.value = pair[0];
      newOption.innerHTML = pair[1];
      s2.options.add(newOption);
    }
  }
</script>
</head>
<body>

<div class="sidenav">
  <a style="background-color: #448ee4; color: white" href="#"><b>E-Attendance</b></a>
  <a href="#">Notifications
  <i class="material-icons" style="font-size: 24px; top: 4px;align-items: center;position: relative;">notifications</i>
  <span class="badge">9</span>
  </a>

  <a href="Faculty_ScheduleLecture.php">Schedule Lectures</a>
  <a href="Faculty_Edit_Attendance.php">Edit Attendance</a>
  <a href="View_Attendance.php">View Attendence</a>
  <a href="Faculty_AddMessage.php">Add Message</a>
  <!-- Logout Button Code-->
  <a href="logout.php">Signout</a>
</div>

<div class="main">
  <div class="container">
    <h1 style="color: blue;text-align: center;">View Attendance</h1><br>
  <form action="View_Attendance.php" method="POST">
    <div class="row">
      <div class="columnB">
        <label for="branch"><b>Branch:</b></label>
        <select class="selectb" name="subject" id="branch">
          <option value="none">--Select--</option>
          <option value="it">Information Technology</option>
          <option value="mech">Mechanical</option>
          <option value="comps">Computer Science</option>
          <option value="extc">EXTC</option>
          <option value="civil">Civil</option>
        </select>
      </div>
      <div class="columnS">
        <label for="sem"><b>Semester:</b></label>
        <select class="selectS" name="sem" id="slct1" onchange="populate(this.id,'slct2')">
          <option value="none">--Select--</option>
          <option value="sem1">Semester I</option>
          <option value="sem2">Semester II</option>
          <option value="sem3">Semester III</option>
          <option value="sem4">Semester IV</option>
          <option value="sem5">Semester V</option>
          <option value="sem6">Semester VI</option>
          <option value="sem7">Semester VII</option>
          <option value="sem8">Semester VIII</option>
        </select>
      </div>
      <div class="columnSB">
        <label for="fsname"><b>Subject:</b></label>
        <select class="selectSB" name="subject" id="slct2">
        </select>
      </div>
    </div>
    <div class="row">
      <div class="column">
        <label for="msg"id="SN" style="padding: 20px;"><b>Date:</b></label>
        <input type="date" name="fdate">
        <label style="padding: 10px"><b>To</b></label>
        <input type="date" name="ldate">
      </div>
    </div><br>
    <div class="row">
      <input type="submit" name="generate" value="Generate Report">
    </div>
  <br><br>

<?php
$host="localhost";
$user="root";
$password="";
$datab="logindb";

$conn=mysqli_connect($host,$user,$password,$datab);

$query= "SELECT * FROM sample_view_table";
$query_run= mysqli_query($conn, $query);
?>

<?php

      if(isset($_POST['generate'])){
?>

  <div class="Table">
  <table class="table table-bordered">
    <tr>
      <th>Roll no.</th>
      <th>Student Name</th>
      <th>Moodle ID</th>
      <th>Present</th>
      <th>Absent</th>
      <th>Total lectures</th>
    </tr>
    <?php
        //echo $new_date;
      if ($query_run) {
          /*while($row = mysqli_fetch_array($query_run)) {
              //echo $row['1.'];*/
    ?>
    <tbody>
    <?php
     while($row = mysqli_fetch_array($query_run))
     {
      echo '
      <tr>
       <td>'.$row["roll_no"].'</td>
       <td>'.$row["student_name"].'</td>
       <td>'.$row["moodle_id"].'</td>
       <td>'.$row["present"].'</td>
       <td>'.$row["absent"].'</td>
       <td>'.$row["total_lectures"].'</td>
      </tr>
      ';
      $student= $row["student_name"];
      $present= $row["present"];
      $total= $row["total_lectures"];
      $percent= $present*100/$total;
      if($percent<75)
      {
        $queryP= "SELECT * FROM parents_detail where c_name='".$student."'";
        $query_runP= mysqli_query($conn, $queryP);
        $row = mysqli_fetch_assoc($query_runP);
        $parentM_num= $row["mobile_num"];
     $fields = array(
    "sender_id" => "TXTIND",
    "message" => ''.$student.' attendance is below 75%. Attendance is '. $present .'/'. $total .'',
    "route" => "v3",
    "numbers" => $parentM_num,
      );

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 60,
  CURLOPT_SSL_VERIFYHOST => 0,
  CURLOPT_SSL_VERIFYPEER => 0,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => json_encode($fields),
  CURLOPT_HTTPHEADER => array(
    "authorization: Put the API Key Here",
    "accept: */*",
    "cache-control: no-cache",
    "content-type: application/json"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo "Messag is send...";
}
      }
     } //While closing bracket
     ?>
    </tbody>
    <?php
    }
    else{
        echo "No record found!!";
      }
    ?>
  </table> <br><br>
  <center><button class="DR">Download Report</button></center>
  </div><br>
  <?php  
    }
  ?>
</form>
  </div>
</div>
<script>
/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}
</script>

</body>
</html> 
