<!DOCTYPE html>
<html>
<head>
<title>About us</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}

.about-section {
  padding: 50px;
  text-align: center;
  background-color: #474e5d;
  color: white;
}

.container {
  padding: 0 16px;
  background-color: white;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

.dropdown {
  float: right;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 15px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.dropdown:hover .dropbtn {
  background-color: #4CAF50;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: black;
  color: white;
}

.dropdown:hover .dropdown-content {
  display: block;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}
</style>
</head>
<body background="none">

<div class="navbar">
      <a class="active" href="example.php"><i class="fa fa-fw fa-home"></i> Home</a> 
      <!--<a href="#" ><i class="fa fa-fw fa-search"></i> Search</a>--> 
      <a href="aboutus.php" class="ab"><i class="fa fa-fw fa-user"></i> About us</a>
      <a href="contactus.php" class="con"><i class="fa fa-fw fa-envelope"></i> Contact us</a>
<div class="dropdown">
    <button class="dropbtn">Login 
      <i class="material-icons" style="font-size: 14px;">input</i>
    </button>
    <div class="dropdown-content">
      <a href="example.php">Admin</a>
      <a href="Faculty_login.php">Faculty</a>
      <a href="student_login.php">Student</a>
      <a href="Parents_login.php">Parents</a>
    </div>
  </div> 
</div>

<div class="about-section">
  <h1>About Us</h1>
  <p style="text-align: justify;text-justify: inter-word;">
<b>One</b> necessary component of every education system is recording student’s attendance. The entire process could be time-consuming if it is managed manually. As a result of rapid growth in information technologies, automatic solutions have become a standard option for these types of education processes.To verify the student attendance record, the personnel staff ought to have an appropriate system for approving and maintaining the attendance record consistently. By and large, there are two kinds of student attendance frameworks, i.e. Manual Attendance System and Automated Attendance System. Practically in the Manual Attendance System, the staff may experience difficulty in both approving and keeping up every student’s record in a classroom all the time.</p>
<p style="text-align: justify;text-justify: inter-word;">In a classroom with a high teacherto-student ratio, it turns into an extremely dreary and tedious process to mark the
attendance physically and cumulative attendance of each student. Consequently, we
can execute a viable framework which will mark the attendance of students
automatically via face recognition. AAS may decrease the managerial work of its staff.
Especially, for an attendance system which embraces Human Face Recognition (HFR),
it normally includes the students' facial images captured at the time he/she is entering
the classroom, or when everyone is seated in the classroom to mark the attendance,
Generally, there are two known methodologies to deal with HFR, one is the featurebased methodology and the other is the brightness-based methodology. The featurebased methodology utilizes key point features present on the face, called landmarks, of
the face, for example, eyes, nose, mouth, edges or some other unique attributes. In this
way, out of the picture that has been extricated beforehand, just some part is covered
during the calculation process.</p>
</div>

<h2 style="text-align:center; color:white;"><b>Our Team</b></h2>
<div class="row">
  <div class="column">
    <div class="card">
      <img src="" alt="Jayesh" style="">
      <div class="container">
        <h2>Jayesh Bhosale</h2>
        <p class="title">B.E (Information Technology)</p>
        <p style="text-align: justify;text-justify: inter-word;">Hii, Myself Jayesh. I have studying in final year of B.E at A.P.Shah Institute Of Technology. If you have any quiery related this project contact me or my team member.</p>
        <p style="color: blue">jayeshnandbhosle@gmail.com</p>
        <p><a href="mailto:jayeshnandbhosle@gmail.com"><button class="button">Contact</button></a></p>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="#" alt="Tejas" style="width:100%">
      <div class="container">
        <h2>Tejas Bhanushali</h2>
        <p class="title">B.E (Information Technology)</p>
        <p style="text-align: justify;text-justify: inter-word;">Hii, Myself Tejas. I have studying in final year of B.E at A.P.Shah Institute Of Technology. If you have any quiery related this project contact me or my team member.</p>
        <p style="color: blue">tejasbhanushali@gmail.com</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <img src="#" alt="Yash" style="width:100%">
      <div class="container">
        <h2>Yash Gangani</h2>
        <p class="title">B.E (Information Technology)</p>
        <p style="text-align: justify;text-justify: inter-word;">Hii, Myself Yash. I have studying in final year of B.E at A.P.Shah Institute Of Technology. If you have any quiery related this project contact me or my team member.</p>
        <p style="color: blue">yashgangani@gmail.com</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>
</div>

</body>
</html>