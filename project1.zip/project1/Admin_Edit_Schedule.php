<?php session_start(); ?>
<?php
$host="localhost";
$user="root";
$password="";
$datab="logindb";

$conn=mysqli_connect($host,$user,$password,$datab);
/*$connect = mysqli_connect("localhost", "root", "", "testing");*/
$query = "SELECT * FROM lecture";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Admin Edit Lecture</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="sidebar.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <script src="jquery.tabledit.min.js"></script>

  <style>
    .editbutton{
      color: white;
    }
      .editbutton:hover{
        background-color: #0082e6;
        color: white;
      }

body {
  font-family: "Lato", sans-serif;
  background-image: url(laptop.jpg);
  background-repeat: no-repeat;
  background-size: cover;
}

/* Main content */
.main {
  margin-left: 180px; /* Same as the width of the sidenav */
  /*font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

/* Add Student Dropdown*/
#adds{ padding-left: 6px; }
#adds:hover{
  color: white;
  background-color: none;
}

#addsDW{
  padding-right: 34px;
}

@media screen and (max-width: 700px) {
  .sidenav {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidenav a {float: left;}
  div.content {margin-left: 0;}
  .sidenav .fa-caret-down {
  float: right;
  /*padding-left: 10px;*/
  padding-right: 310px;
  
}
.main {
  margin-left: 5px; /* Same as the width of the sidenav */
  /*font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

#addsDW{
  padding-right: 306px;
}

}/*media screen bracket close*/

/*Container style*/
* {
  box-sizing: border-box;
}

input[type=text], select, textarea {
  width: 40%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
  color: white;
  font-size: 18px;
}

input[type=submit] {
  background-color: #448ee4;
  color: white;
  width: 100px;
  height: 40px;
  font-size: 15px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  position: relative;
  text-align: center;
  
}

input[type=submit]:hover {
  background-color: #4CAF50;
}

.container {
  text-align: center;
  border-radius: 5px;
  background-color: transparent;
  padding: 20px;
  opacity: 0.9;
}


/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

#SN{
  
  padding: 10px;
}

/*table css*/
table td,th{
  border-collapse: collapse;
  border: 2px solid black;
}
table {
  width: 100%;
  border-collapse: collapse;
  background-color: white;
  text-align: center;
}
table th{
  background-color: red;
}

/*save and cancel button CSS*/
.save{
  color: white;
  width: 90px;
  height: 40px;
  font-size: 15px;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  position: relative;
  background-color: #4CAF50;
}
.save:hover{
  background-color: red;
}
.cancel{
  color: white;
  width: 90px;
  height: 40px;
  font-size: 15px;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  padding: 10px;
  background-color: #4CAF50;
}
.cancel:hover{
  background-color: #448ee4;
}

/*Edit and delete button*/
.edit{
  color: white;
  width: 50px;
  height: 20px;
  font-size: 15px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  background-color: #448ee4;
  text-align: center;
}
.delete{
  color: white;
  width: 60px;
  height: 20px;
  font-size: 15px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  background-color: #448ee4;
  text-align: center;
}
.edit:hover{
  box-shadow: 2px 2px black;
}
.delete:hover{
  box-shadow: 2px 2px black;
}
</style>    
  </head>
  <body>
    <div id="Sidenav" class="sidebar">
        <a class="active" href="#">E-Attendence</a>
        <button class="dropdown-btn">Registration 
          <i class="fa fa-caret-down"></i>
        </button>
        <div class="dropdown-container">
          <button class="dropdown-btn">Add Students 
            <i class="fa fa-caret-down"></i>
          </button>
          <div class="dropdown-container">
            <a href="Add_Student.php">Register Student</a>
            <a href="#">Face Enrollment</a>
          </div>
          <a href="Add_Parents.php">Add Parents</a>
          <a href="#">Add Faculty</a>
        </div>

        <a href="Schedule_Lec_Admin.php">Schedule Lectures</a>
        <a href="Admin_ViewAttendance.php">View Attendance</a>
        <!--<a href="#">Camera/Classroom settings</a> -->
        <!-- Logout Button Code-->
        <a href="logout.php">Logout</a>

        
    </div>
    
    <div class="main">
  <div class="container">
    <h2 style="color: Green;text-align: center;">Edit Lecture</h2><br>
  <form action="Admin_Edit_Schedule.php">
    <div class="row">
      <div class="column">
        <label for="msg"id="SN" style="padding: 15px;color: red;"><b>Date:</b></label>
        <input type="date" name="Edate">
      </div>
    </div><br>
    <div class="row">
      <input type="submit" name="show" style="width: 60px;height: 40px;padding-left: 98px;" value="Show Lectures">
    </div>
  <br><br>
<?php
$host="localhost";
$user="root";
$password="";
$datab="logindb";

$conn=mysqli_connect($host,$user,$password,$datab);

$query= "select * FROM lecture";
$query_run= mysqli_query($conn, $query);
?>

<!-- <?php

      if(isset($_POST['submit'])){
?>-->
  <div class="Table">
  <table id="editable_table" class="table table-bordered">
    <tr>
      <th>Sr no.</th>
      <th>Subject</th>
      <th>Date</th>
      <th>Timing</th>
    </tr>
    
    <?php
        //echo $new_date;
      if ($query_run) {
          /*while($row = mysqli_fetch_array($query_run)) {
              //echo $row['1.'];*/
    ?>
    <tbody>
    <?php
     while($row = mysqli_fetch_array($query_run))
     {
      echo '
      <tr>
       <td>'.$row["id"].'</td>
       <td>'.$row["subject"].'</td>
       <td>'.$row["date"].'</td>
       <td>'.$row["timing"].'</td>
      </tr>
      ';
     }
     ?>
    </tbody>
    <?php
    }
    else{
        echo "No record found!!";
      }
    ?>
    
  </table>
  </div><br>
  <!--<?php  
    }
    ?> -->
  </form>
  </div>
</div>
<script>
      function openNav() {
        document.getElementById("Sidenav").style.width = "250px";
        document.getElementById("main").style.marginLeft = "250px";
        document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
      }
      
      function closeNav() {
        document.getElementById("Sidenav").style.width = "0";
        document.getElementById("main").style.marginLeft= "0";
        document.body.style.backgroundColor = "white";
      }
      </script>
<script>
/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}
</script> 
<script> 
$(document).ready(function(){  
     $('#editable_table').Tabledit({
      url:'editlecaction.php',
      buttons: {
        edit: {
            class: 'btn btn-sm btn-primary',
            html:'<span class="glyphicon glyphicon-pencil"></span> &nbsp EDIT',
            action: 'edit'
        }
        delete: {
            class: 'btn btn-sm btn-primary',
            html:'<span class="glyphicon glyphicon-pencil"></span> &nbsp DELETE',
            action: 'delete'
        }
    },
      columns:{
       identifier:[0, "id"],
       editable:[[1, 'subject'], [2, 'date'], [3, 'timing']]
      },
      restoreButton:false,
      onSuccess:function(data, textStatus, jqXHR)
      {
       if(data.action == 'delete')
       {
        $('#'+data.id).remove();
       }
      }
     });
 
}); 
</script>
  </body>
</html>
