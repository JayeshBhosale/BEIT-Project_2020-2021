<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Add Faculty</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="sidebar.css">
    <style>

    </style>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script>
/*  function populate(s1,s2)
  {
    var s1 = document.getElementById(s1);
    var s2 = document.getElementById(s2);
    s2.innerHTML = "";

    if(s1.value==="sem3")
    {
      var optionArray= ['mathII|Applied MathsIII','ld|Logic Design','dsa|DSA','dbms|DBMS','poc|POC','ddl|Digital Design Lab','dsl|Data Structure Lab','sql|SQL Lab','jpl|Java Programming Lab'];
    }
    else if(s1.value==="sem4")
    {
      var optionArray= ['mathIV|Applied MathsIV','cn|Computer Network','os|Operating Systems','coa|COA','at|Automata Theory','nl|Networking Lab','ul|Unix Lab','mpl|MPL','pl|Python Lab'];
    }
    else if(s1.value==="sem5")
    {
      var optionArray= ['mep|MEP','ip|Internet Programming','admt|ADMT','cns|CNS','ecom|E-Commerce','cgvr|CGVR','ipl|IPL','sl|Security Lab','olab|OLAP Lab','iot|IOT Lab','bce|BCE'];
    }
    else if(s1.value==="sem6")
    {
      var optionArray= ['sepm|SEPM','dmbi|DMBI','ccs|CCS','wn|WN','aip|AIP','df|DF','sdl|Software Design Lab','bil|BIL','csdl|Cloud Service Design Lab','snl|Sensor Network Lab','mp|Mini Project'];
    }
    else if(s1.value==="sem7")
    {
      var optionArray= ['end|Enterprise Network Design','is|Infrastructure Security','ai|Artificial Intelligence','mad|MAD','stqa|STQA','csl|Cyber Security and Law','mis|Management Information System','ndl|Network Design Lab','asl|Advanced Security Lab','isl|Intelligence System Lab','aadl|AADL','p1|Project-I'];
    }
    else if(s1.value==="sem8")
    {
      var optionArray= ['bda|BDA','ioe|IOE','erp|ERP','uid|UID','pm|Project Management','evm|Environmental Management','bdl|Big Data Lab','ioel|IOE Lab','dl|DevOps Lab','rpl|R Programming Lab','p2|Project-II'];
    }

    for(var option in optionArray){
      var pair = optionArray[option].split("|");
      var newOption = document.createElement("option");
      newOption.value = pair[0];
      newOption.innerHTML = pair[1];
      s2.options.add(newOption);
    }
  } */
</script>
  </head>
  <body>
    <div id="Sidenav" class="sidebar">

      
      <!--<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>-->
        <a class="active" href="#">E-Attendence</a>
        <button class="dropdown-btn">Registration 
          <i class="fa fa-caret-down"></i>
        </button>
        <div class="dropdown-container">
          <button class="dropdown-btn">Add Students 
            <i class="fa fa-caret-down" ></i>
          </button>
          <div class="dropdown-container">
            <a href="#">Register Student</a>
            <a href="face_enrollment.php">Face Enrollment</a>
          </div>
          <a href="Add_Parents.php">Add Parents</a>
          <a href="add_faculty.php">Add Faculty</a>
        </div>

        <a href="Schedule_Lec_Admin.php">Schedule Lectures</a>
        <a href="#">View Attendence</a>
        <!-- <a href="#">Camera/Classroom settings</a> -->
        <!-- Logout Button Code-->
        <a href="logout.php">Logout</a>

    </div>

    <div id="main" style="padding-left: 200px;">
       
      <!--<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span> -->

    <center>

    <h2>Faculty Info</h2>
    <br>
    <br>
    
    <div class="container">
      <form>
        <div class="row">
          <div class="col-25">
            <label for="fname">Name</label>
          </div>
          <div class="col-75">
            <input type="text" id="name" name="fname" placeholder="Faculty name..">
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label for="fid">Faculty Id</label>
          </div>
          <div class="col-75">
            <input type="text" id="fid" name="fid" placeholder="Faculty Id">
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label for="Email">Email Id</label>
          </div>
          <div class="col-75">
            <input type="text" id="Email" name="Email" placeholder="Email Id">
          </div>
        </div>
        <div class="row">
            <div class="col-25">
              <label for="Smnum">Mobile Number</label>
            </div>
            <div class="col-75">
              <input type="text" id="moodle id" name="mobilenum" placeholder="Mobile Number..">
            </div>
          </div>

        <div class="row">
            <div class="col-25">
                <label for="uploadimage">Upload Photo</label>
            </div>
            <div class="col-75">
                <input type="file" id="uploadimage" name="uploadimage">
                <button class="button button4" input type="submit">Upload</button>
            </div>
        </div>

        <div class="row">
          <input type="submit" value="Register">
        </div>
        <br>
        <br>
        OR
        <br>
        <br>
        <div class="row">
            <div class="col-25">
                <label for="uploadimage">Upload bulk file</label>
            </div>
            <div class="col-75">
                <input type="file" id="uploadfile" name="uploadfile">
                <button class="button button4" input type="submit">Upload</button>
            </div>
        </div>
        
        <div class="row">
          <input type="submit" value="Submit">
        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>


        <h2>Acedamic Info</h2>
        <br>
        <br>
        <br>
        <br>
        <br>

        <div class="row">
            <div class="col-25">
              <label for="sname">Academic Year</label>
            </div>
            <div class="col-75">
            <select id="relation" name="relation">
              <option value="none">--Select--</option>
              <option value="">17-18</option>
              <option value="">18-19</option>
              <option value="">19-20</option>
              <option value="">20-21</option>
              
            </select>
          </div>
          </div>
        <div class="row">
          <div class="col-25">
            <label for="branch">Branch</label>
          </div>
            <div class="col-75">
            <select class="selectb" name="subject" id="branch">
              <option value="none">--Select--</option>
              <option value="it">Information Technology</option>
              <option value="mech">Mechanical</option>
              <option value="comps">Computer Science</option>
              <option value="extc">EXTC</option>
              <option value="civil">Civil</option>
            </select>
          </div>
        <div class="row">
          <div class="col-25">
            <label for="relation">Semester</label>
          </div>
          <div class="col-75">
          <select class="selectS" name="sem" id="slct1" onchange="populate(this.id,'slct2')">
            <option value="none">--Select--</option>
            <option value="sem1">Semester I</option>
            <option value="sem2">Semester II</option>
            <option value="sem3">Semester III</option>
            <option value="sem4">Semester IV</option>
            <option value="sem5">Semester V</option>
            <option value="sem6">Semester VI</option>
            <option value="sem7">Semester VII</option>
            <option value="sem8">Semester VIII</option>
            </select>
          </div>
        </div>
        <br>
        <br>
        <br>


        <h3>Semester 3</h3>
        <br>
        <br>


        <div class="row" id="slct2">
            <div class="col-25">
              <label for="TheorySubject">Theory Subject</label>
            </div>
            <div class="col-75">
            <form action="/action_page.php">
            <input type="checkbox" id="DSA" name="DSA" value="DSA">
            <label for="DSA">DSA</label><br>
            <input type="checkbox" id="DBMS" name="DBMS" value="DBMS">
            <label for="DBMS">DBMS</label><br>
            <input type="checkbox" id="POC" name="POC" value="POC">
            <label for="POC">POC</label><br>
            <input type="checkbox" id="AM-III" name="AM-III" value="AM-III">
            <label for="AM-III">AM-III</label><br><br>
            </form>
            </div>

            <div class="col-25" id="slct2">
              <label for="TheorySubject">Practical Subject</label>
            </div>
            <div class="col-75">
            <form action="/action_page.php">
            <input type="checkbox" id="DSA" name="DSA" value="DSA">
            <label for="DSAlab">DSA Lab</label><br>
            <input type="checkbox" id="DBMS" name="DBMS" value="DBMS">
            <label for="SQLlab">SQL Lab</label><br>
            <input type="checkbox" id="POC" name="POC" value="POC">
            <label for="POClab">POC Lab</label><br><br>
            <input type="submit" value="Submit">
            </form>
            </div>
        </div>


        
      
    </div>

    </center>
  </div>


    <!--<script>
      function openNav() {
        document.getElementById("Sidenav").style.width = "250px";
        document.getElementById("main").style.marginLeft = "250px";
        document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
      }
      
      function closeNav() {
        document.getElementById("Sidenav").style.width = "0";
        document.getElementById("main").style.marginLeft= "0";
        document.body.style.backgroundColor = "white";
      }
      </script>-->
      <script>
        var dropdown = document.getElementsByClassName("dropdown-btn");
        var i;

        for (i = 0; i < dropdown.length; i++) {
        dropdown[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var dropdownContent = this.nextElementSibling;
        if (dropdownContent.style.display === "block") {
        dropdownContent.style.display = "none";
        } else {
        dropdownContent.style.display = "block";
        }
        });
      }
      </script>   
  </body>
</html>
