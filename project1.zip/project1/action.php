<?php 
$host="localhost";
$user="root";
$password="";
$datab="logindb";

$conn=mysqli_connect($host,$user,$password,$datab);

$input = filter_input_array(INPUT_POST);

/*$rno= $row['rno'];
$sname= $row['sname'];
$moodle_id= $row['moodle_id'];
$Date= $row['Date'];
$timing= $row['timing'];
$status= $row['status'];*/

$sname = mysqli_real_escape_string($conn, $input["sname"]);
$moodle_id = mysqli_real_escape_string($conn, $input["moodle_id"]);
$Date = mysqli_real_escape_string($conn, $input["Date"]);
$timing = mysqli_real_escape_string($conn, $input["timing"]);
$status = mysqli_real_escape_string($conn, $input["status"]);

if($input["action"] === 'edit')
{
 $query = "
 update attendance 
 set sname = '".$sname."', 
 moodle_id = '".$moodle_id."', 
 Date = '".$Date."', 
 timing = '".$timing."', 
 status = '".$status."' 
 WHERE rno = '".$input["rno"]."'
 ";

 mysqli_query($conn, $query);

}
/*if($input["action"] === 'delete')
{
 $query = "
 DELETE FROM tbl_user 
 WHERE id = '".$input["id"]."'
 ";
 mysqli_query($connect, $query);
}*/

echo json_encode($input);

?>